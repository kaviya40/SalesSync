# SalesSync API

Base URL: `http://localhost:5000/api`. JSON in/out. All routes except `health` and `auth/*` need `Authorization: Bearer <JWT>`.
Errors: `{ "success": false, "message": "..." }` with status 400 (validation), 401 (no/invalid token), 403 (role), 404, 409 (duplicate / insufficient stock), 429 (rate limit).
Roles: **A**=ADMIN, **O**=OWNER, **S**=STAFF. Lists accept `page` & `limit` (max 100) and return `{ items, total, page, pages }`.

## Auth
| Method | Path | Access | Body / notes |
|---|---|---|---|
| GET | /health | public | health check |
| POST | /auth/register | public | `{name,email,password}` → STAFF user + `{token,user}` |
| POST | /auth/login | public | `{email,password}` → `{token,user}` |
| POST | /auth/google | public | `{credential}` (Google ID token) → `{token,user}`; 501 if `GOOGLE_CLIENT_ID` unset |
| GET | /auth/me | any | current user |

## Admin (A only)
| Method | Path | Notes |
|---|---|---|
| GET | /admin/stats | user/product/customer/sale counts, revenue |
| GET | /admin/users | `?q=&role=&page=` |
| POST | /admin/users | `{name,email,password,role}` |
| PATCH | /admin/users/:id | `{role?,isActive?}` (cannot demote/disable yourself) |

## Products
| Method | Path | Access | Notes |
|---|---|---|---|
| GET | /products | all | `q, category, stockStatus=in\|low\|out, minPrice, maxPrice, sort=name\|price\|stock\|createdAt\|category, order, page, limit` |
| GET | /products/categories | all | distinct categories |
| GET | /products/:id | all | product + last 10 stock movements (records recent activity) |
| POST | /products | A,O | `multipart/form-data`: name, price, sku?, category?, color?, size?, costPrice?, stock? (opening), lowStockThreshold?, unit?, aliases? (comma list), description?, image? (file) |
| PUT | /products/:id | A,O | same fields (stock is not editable here) |
| DELETE | /products/:id | A,O | soft delete |

## Inventory
| Method | Path | Access | Notes |
|---|---|---|---|
| POST | /inventory/adjust | A,O | `{productId, type:"ADD"\|"REDUCE", quantity, reason?}`; REDUCE below zero → 409 |
| GET | /inventory/transactions | all | `?product=&type=ADD\|REDUCE\|SALE` |

## Sales
| Method | Path | Access | Notes |
|---|---|---|---|
| POST | /sales | all | `{items:[{productId,quantity}], customerId?, discount?, paymentMethod?: CASH\|CARD\|UPI\|OTHER, note?}` — totals computed server-side; 409 if stock is insufficient |
| GET | /sales | all (S sees own) | `?from=YYYY-MM-DD&to=&customer=` |
| GET | /sales/:id | all (S own) | sale detail |

## Customers
| Method | Path | Access |
|---|---|---|
| GET | /customers (`?q=`) | all |
| GET | /customers/:id | all (with recent sales) |
| POST | /customers | all — `{name, phone?, email?, address?, notes?}` |
| PUT | /customers/:id | all |
| DELETE | /customers/:id | A,O (soft delete) |

## Reports
| Method | Path | Access | Notes |
|---|---|---|---|
| GET | /reports/overview | all (S = own sales) | dashboard data |
| GET | /reports/sales | all (S own) | `?period=daily\|weekly\|monthly` → `{series[{periodStart,revenue,orders,units}], totals}` |
| GET | /reports/top-products | all (S own) | `?days=30` |
| GET | /reports/stock | A,O | totals, low stock, out of stock, by category |

## Notifications, recent items
| Method | Path | Notes |
|---|---|---|
| GET | /notifications | active low/out-of-stock alerts + `unread` count |
| PATCH | /notifications/:id/read · /notifications/read-all | mark read |
| GET | /recent | `?type=product\|sale\|customer\|report&limit=` — current user's recently opened items |
| POST | /recent | `{entityType, entityId}` records an open |

## Voice
`POST /voice/command` — body `{ "transcript": "sell 2 smartphones", "context": { ...from previous response } }`

Response: `{ success, type, intent?, message, data?, refresh[], navigate?, context }`.
`type` is one of `SELL, ADD, REDUCE, QUERY, SHOW_SALES, SHOW_LOW_STOCK, CLARIFY, NOT_FOUND, FORBIDDEN, ERROR, UNKNOWN`. Send the returned `context` back on the next call so clarifications and follow-ups ("add 5 more") work.

## Data model (collections)
`users`, `products`, `sales`, `customers`, `inventorytransactions`, `notifications`, `recentactivities` (Mongoose default pluralisation).
