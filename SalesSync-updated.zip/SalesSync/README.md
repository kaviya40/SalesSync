# SalesSync — Unified Sales & Inventory Platform

A full-stack MERN application for small shops: products, stock, sales, customers, reports, role-based access and a **Voice-to-Transaction** assistant that actually executes commands such as *"Sell 2 smartphones"* or *"10 shirt stock la add pannu"*.

> **Verification status (please read):** this project was written and statically checked in an environment with **no internet and no MongoDB**, so `npm install`, `vite build`, a live MongoDB, Google OAuth and the microphone were **not** exercised. See [What was and wasn't tested](#what-was-and-wasnt-tested). Expect to run the checklist in SETUP.md and fix small things if any appear.

## Tech stack
- **Client:** React 18, Vite, JSX, React Router 6, Redux Toolkit, Bootstrap 5 + custom CSS, Recharts, custom hooks `useFetch()` and `useVoiceCommand()`
- **Server:** Node.js (>=18), Express, Mongoose 8, JWT, bcryptjs, multer, helmet, express-rate-limit, google-auth-library
- **Database:** MongoDB 5.0+ (needed for `$dateTrunc` in reports; a replica set / Atlas is needed for multi-document transactions)

## Folder structure
```
SalesSync/
├── client/                 React + Vite app
│   └── src/ components/ pages/ hooks/ services/ redux/ utils/ App.jsx main.jsx
├── server/
│   ├── config/ models/ routes/ controllers/ middleware/ services/ validators/ utils/
│   ├── scripts/createUser.js   create the first admin / any user (secure CLI)
│   ├── tests/voiceParser.test.js   17 offline tests of the voice parser
│   └── server.js
├── README.md   SETUP.md   API.md
```

## Features
| Area | What's implemented |
|---|---|
| Auth | Register, login, logout, Google sign-in (Google Identity Services + server-side ID-token verification), JWT, bcrypt (12 rounds), rate-limited auth routes |
| Roles | **ADMIN** (everything + user management), **OWNER** (products, stock, customers, all reports), **STAFF** (sell, view products, manage customers, own sales only) |
| Products | CRUD (soft delete), search, category/stock/price filters, sorting, pagination, image upload (JPG/PNG/WEBP/GIF ≤ 2 MB), variants via colour/size, spoken aliases |
| Inventory | Add / reduce stock with reason, full movement ledger (`inventoryTransactions`) |
| Sales | Multi-item sales, backend price/total calculation, stock validation, insufficient-stock rejection, history, invoice detail |
| Integrity | Atomic conditional stock decrement (`stock >= qty`) prevents overselling; MongoDB transaction when available, compensating rollback otherwise |
| Alerts | Low-stock / out-of-stock notifications created and auto-resolved as stock changes |
| Customers | CRUD, purchase totals, recent sales |
| Recent items | Recently opened products, sales, customers and reports (`recentActivities`) |
| Reports | Daily / weekly / monthly sales, top sellers, stock report — all aggregated live from MongoDB |
| Voice | Mic → Web Speech API → server parser → validation → MongoDB → UI refresh; clarification questions and follow-ups |
| Data | **No hard-coded business data.** The DB starts empty. |

## Voice-to-Transaction
Click the amber mic button (bottom-right). Chrome/Edge are recommended (Firefox has no Speech Recognition). You can also **type** the same commands in the panel.

| Say / type | Result |
|---|---|
| "Add 10 shirts to stock" | Adds stock (OWNER/ADMIN only) |
| "Sell 2 smartphones" | Creates a real sale, reduces stock, writes ledger + notifications |
| "How many chargers are available?" | Reads current stock |
| "Show today's sales" | Summary + opens Sales page |
| "Blue shirt 5 sell pannu" / "10 shirt stock la add pannu" | Tanglish supported |
| "Show low stock" | Lists low / out-of-stock items |

Behaviour rules:
- **Unknown product →** "Please add it first" (voice never creates products).
- **Ambiguous product →** asks which one (e.g. *Blue Shirt M / Red Shirt L*). Answer with "blue", "the second one", or "2".
- **Missing quantity →** asks "How many…?".
- **Context →** after "Sell 2 smartphones", "add 5 more" or "how many are left?" refer to the same product.
- Tamil/Tanglish number words (*onnu, rendu, moonu, naalu, anju, aaru, ezhu, ettu, onbadhu, pathu*) and common Tamil-script verbs are recognised. Add Tamil/Tanglish product names in the product's **Spoken names** field so they can be matched.
- Limits: recognition quality for Tamil depends on the browser's engine; the parser is rule-based, not an LLM, so unusual phrasing may need rewording.

## Business-rule details
- Prices and totals are always computed on the server from product records.
- `findOneAndUpdate({_id, stock: {$gte: qty}}, {$inc: {stock: -qty}})` makes each decrement atomic, so concurrent sales cannot push stock below zero.
- **With a replica set / Atlas** the whole sale (stock, sale, ledger, customer totals) is one transaction.
- **On a standalone local MongoDB** transactions don't exist; the server detects this at startup and falls back to atomic updates plus compensating rollback (restore stock, delete partial records). The startup log prints which mode is active.

## Quick start (Windows CMD)
See **SETUP.md** for the full guide. Short version:
```bat
cd SalesSync\server
copy .env.example .env
npm install
npm run create-user -- --name "Admin" --email admin@example.com --role ADMIN
npm run dev
```
In a second terminal:
```bat
cd SalesSync\client
copy .env.example .env
npm install
npm run dev
```
Open http://localhost:5173.

## External credentials you must provide
1. **MongoDB connection string** (Atlas free tier or local) → `server/.env` `MONGODB_URI`
2. **JWT secret** (random 32+ chars; generator command in SETUP.md) → `server/.env` `JWT_SECRET`
3. **Google OAuth Web Client ID** *(optional)* → `server/.env` `GOOGLE_CLIENT_ID` and `client/.env` `VITE_GOOGLE_CLIENT_ID`

## What was and wasn't tested
**Done (in the build environment):**
- All server `.js` files pass `node --check`.
- Module wiring: every route handler resolves to a defined controller function (load test with stubbed packages).
- Voice parser: `npm run test:voice` — 17 tests pass (English, Tanglish, Tamil-script verbs, ambiguity, follow-ups, unknown product).
- All 31 client `.js/.jsx` files parse without syntax errors; all relative imports resolve.

**NOT done (no network / no database available) — you need to run these:**
- `npm install` for both apps, `npm run build` for the client
- Connecting to MongoDB, real API calls, role/permission checks, sale/stock flows, transaction and fallback modes
- Concurrency (two simultaneous sales on the last unit)
- Reports aggregation (needs MongoDB ≥ 5.0)
- Google OAuth (needs your own client ID), image upload, microphone/speech in a real browser, Tamil recognition
- Responsive layout on real devices

Do not treat Google login, voice execution against live data, or transactions as working until you've run the checklist in SETUP.md §9.
