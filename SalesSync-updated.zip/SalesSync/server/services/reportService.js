const mongoose = require('mongoose');
const Sale = require('../models/Sale');
const Product = require('../models/Product');
const { env } = require('../config/env');

const DAY = 24 * 60 * 60 * 1000;

function startOfTodayInTz() {
  // Midnight "today" in the configured timezone, expressed as a UTC Date
  const now = new Date();
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: env.reportTimezone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(now);
  const [y, m, d] = parts.split('-').map(Number);
  const asUtc = Date.UTC(y, m - 1, d);
  const tzNow = new Date(now.toLocaleString('en-US', { timeZone: env.reportTimezone }));
  const offset = tzNow.getTime() - new Date(now.toLocaleString('en-US', { timeZone: 'UTC' })).getTime();
  return new Date(asUtc - offset);
}

const PERIODS = {
  daily: { unit: 'day', count: 14 },
  weekly: { unit: 'week', count: 12 },
  monthly: { unit: 'month', count: 12 },
};

function rangeFor(period) {
  const cfg = PERIODS[period] || PERIODS.daily;
  const today = startOfTodayInTz();
  let from;
  if (cfg.unit === 'day') from = new Date(today.getTime() - (cfg.count - 1) * DAY);
  else if (cfg.unit === 'week') from = new Date(today.getTime() - cfg.count * 7 * DAY);
  else from = new Date(today.getTime() - cfg.count * 31 * DAY);
  return { from, unit: cfg.unit };
}

const scope = (user) => (user && user.role === 'STAFF' ? { createdBy: user._id } : {});

async function salesReport(period, user) {
  const { from, unit } = rangeFor(period);
  const match = { createdAt: { $gte: from }, ...scope(user) };

  const series = await Sale.aggregate([
    { $match: match },
    { $addFields: { units: { $sum: '$items.quantity' }, bucket: { $dateTrunc: { date: '$createdAt', unit, timezone: env.reportTimezone, startOfWeek: 'monday' } } } },
    { $group: { _id: '$bucket', revenue: { $sum: '$total' }, orders: { $sum: 1 }, units: { $sum: '$units' } } },
    { $sort: { _id: 1 } },
    { $project: { _id: 0, periodStart: '$_id', revenue: { $round: ['$revenue', 2] }, orders: 1, units: 1 } },
  ]);

  const totals = series.reduce((t, r) => ({ revenue: t.revenue + r.revenue, orders: t.orders + r.orders, units: t.units + r.units }), { revenue: 0, orders: 0, units: 0 });
  return { period: PERIODS[period] ? period : 'daily', from, series, totals };
}

async function topProducts(days, user, limit = 10) {
  const from = new Date(Date.now() - (Number(days) || 30) * DAY);
  return Sale.aggregate([
    { $match: { createdAt: { $gte: from }, ...scope(user) } },
    { $unwind: '$items' },
    { $group: { _id: '$items.product', name: { $first: '$items.name' }, unitsSold: { $sum: '$items.quantity' }, revenue: { $sum: '$items.lineTotal' } } },
    { $sort: { unitsSold: -1, revenue: -1 } },
    { $limit: limit },
    { $project: { _id: 0, productId: '$_id', name: 1, unitsSold: 1, revenue: { $round: ['$revenue', 2] } } },
  ]);
}

async function stockReport() {
  const active = { isActive: true };
  const [summary] = await Product.aggregate([
    { $match: active },
    { $group: { _id: null, products: { $sum: 1 }, units: { $sum: '$stock' }, retailValue: { $sum: { $multiply: ['$stock', '$price'] } }, costValue: { $sum: { $multiply: ['$stock', '$costPrice'] } } } },
  ]);
  const lowStock = await Product.find({ ...active, stock: { $gt: 0 }, $expr: { $lte: ['$stock', '$lowStockThreshold'] } }).sort({ stock: 1 }).limit(100).select('name sku color size stock lowStockThreshold category');
  const outOfStock = await Product.find({ ...active, stock: 0 }).sort({ name: 1 }).limit(100).select('name sku color size category');
  const byCategory = await Product.aggregate([
    { $match: active },
    { $group: { _id: '$category', products: { $sum: 1 }, units: { $sum: '$stock' } } },
    { $sort: { units: -1 } },
    { $project: { _id: 0, category: '$_id', products: 1, units: 1 } },
  ]);
  return {
    summary: summary ? { products: summary.products, units: summary.units, retailValue: Math.round(summary.retailValue * 100) / 100, costValue: Math.round(summary.costValue * 100) / 100 } : { products: 0, units: 0, retailValue: 0, costValue: 0 },
    lowStock,
    outOfStock,
    byCategory,
  };
}

async function todaySummary(user, period = 'today') {
  let from = startOfTodayInTz();
  if (period === 'week') from = new Date(from.getTime() - 6 * DAY);
  if (period === 'month') from = new Date(from.getTime() - 29 * DAY);
  const [row] = await Sale.aggregate([
    { $match: { createdAt: { $gte: from }, ...scope(user) } },
    { $group: { _id: null, orders: { $sum: 1 }, revenue: { $sum: '$total' }, units: { $sum: { $sum: '$items.quantity' } } } },
  ]);
  return { orders: row?.orders || 0, revenue: Math.round((row?.revenue || 0) * 100) / 100, units: row?.units || 0, from };
}

async function overview(user) {
  const [today, stock, top, week] = await Promise.all([
    todaySummary(user, 'today'),
    Product.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: null, products: { $sum: 1 }, low: { $sum: { $cond: [{ $and: [{ $gt: ['$stock', 0] }, { $lte: ['$stock', '$lowStockThreshold'] }] }, 1, 0] } }, out: { $sum: { $cond: [{ $eq: ['$stock', 0] }, 1, 0] } } } },
    ]),
    topProducts(30, user, 5),
    salesReport('daily', user),
  ]);
  const s = stock[0] || { products: 0, low: 0, out: 0 };
  return { today, products: s.products, lowStock: s.low, outOfStock: s.out, topProducts: top, trend: week.series };
}

module.exports = { salesReport, topProducts, stockReport, todaySummary, overview };
