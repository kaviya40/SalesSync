const crypto = require('crypto');
const Sale = require('../models/Sale');
const Product = require('../models/Product');
const Customer = require('../models/Customer');
const InventoryTransaction = require('../models/InventoryTransaction');
const HttpError = require('../utils/HttpError');
const { round2, assertObjectId } = require('../utils/helpers');
const { withTransaction } = require('./stockService');
const { syncMany } = require('./notificationService');
const { recordActivity } = require('./activityService');

function invoiceNumber() {
  const d = new Date();
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  return `INV-${ymd}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

/**
 * Creates a sale. Prices/totals are calculated on the server from the product records.
 * - Stock is decremented with an atomic conditional update ({stock >= qty}) so two concurrent
 *   sales can never oversell.
 * - With a replica set everything runs in one transaction (all-or-nothing).
 * - Without one, already-applied steps are compensated manually if a later step fails.
 */
async function createSale({ items, customerId, discount = 0, paymentMethod = 'CASH', note }, user, source = 'manual') {
  if (!Array.isArray(items) || items.length === 0) throw new HttpError(400, 'A sale needs at least one item');
  if (items.length > 100) throw new HttpError(400, 'Too many items in one sale');

  const merged = new Map();
  for (const it of items) {
    assertObjectId(it.productId, 'product id');
    const qty = Number(it.quantity);
    if (!Number.isInteger(qty) || qty < 1 || qty > 100000) throw new HttpError(400, 'Each quantity must be a whole number of at least 1');
    merged.set(String(it.productId), (merged.get(String(it.productId)) || 0) + qty);
  }
  const disc = Number(discount) || 0;
  if (disc < 0) throw new HttpError(400, 'Discount cannot be negative');
  if (!['CASH', 'CARD', 'UPI', 'OTHER'].includes(paymentMethod)) throw new HttpError(400, 'Invalid payment method');

  let customer = null;
  if (customerId) {
    assertObjectId(customerId, 'customer id');
    customer = await Customer.findOne({ _id: customerId, isActive: true });
    if (!customer) throw new HttpError(404, 'Customer not found');
  }

  const applied = []; // for compensation when transactions are unavailable
  let createdSaleId = null;
  let usedSession = false;

  try {
    const { sale, updatedProducts } = await withTransaction(async (session) => {
      usedSession = Boolean(session);
      const lineItems = [];
      const updated = [];

      for (const [pid, qty] of merged) {
        const after = await Product.findOneAndUpdate(
          { _id: pid, isActive: true, stock: { $gte: qty } },
          { $inc: { stock: -qty } },
          { new: true, session }
        );
        if (!after) {
          const p = await Product.findById(pid).session(session);
          if (!p || !p.isActive) throw new HttpError(404, 'One of the products does not exist');
          throw new HttpError(409, `Insufficient stock for ${p.name}. Available: ${p.stock}, requested: ${qty}`);
        }
        applied.push({ pid, qty });
        updated.push(after);
        lineItems.push({ product: after._id, name: [after.name, after.color, after.size].filter(Boolean).join(' '), sku: after.sku, quantity: qty, unitPrice: after.price, lineTotal: round2(after.price * qty) });
      }

      const subtotal = round2(lineItems.reduce((s, l) => s + l.lineTotal, 0));
      if (disc > subtotal) throw new HttpError(400, 'Discount cannot exceed the subtotal');

      const [created] = await Sale.create(
        [{ invoiceNumber: invoiceNumber(), items: lineItems, customer: customer?._id, customerName: customer?.name, subtotal, discount: round2(disc), total: round2(subtotal - disc), paymentMethod, note, source, createdBy: user._id }],
        { session }
      );
      createdSaleId = created._id;

      await InventoryTransaction.create(
        updated.map((p, i) => ({
          product: p._id,
          productName: p.name,
          type: 'SALE',
          quantityChange: -lineItems[i].quantity,
          stockBefore: p.stock + lineItems[i].quantity,
          stockAfter: p.stock,
          reason: `Sale ${created.invoiceNumber}`,
          sale: created._id,
          source,
          createdBy: user._id,
        })),
        { session, ordered: true }
      );

      if (customer) {
        await Customer.updateOne({ _id: customer._id }, { $inc: { totalPurchases: created.total }, $set: { lastPurchaseAt: new Date() } }, { session });
      }
      return { sale: created, updatedProducts: updated };
    });

    // Non-critical follow-ups (after the sale is safely committed)
    await syncMany(updatedProducts);
    await recordActivity({ user, entityType: 'sale', entityId: sale._id, label: sale.invoiceNumber, action: 'created' });
    return { sale, products: updatedProducts };
  } catch (err) {
    if (!usedSession) {
      // Compensate manually: restore stock and remove partial records
      for (const a of applied) await Product.updateOne({ _id: a.pid }, { $inc: { stock: a.qty } }).catch(() => {});
      if (createdSaleId) {
        await Sale.deleteOne({ _id: createdSaleId }).catch(() => {});
        await InventoryTransaction.deleteMany({ sale: createdSaleId }).catch(() => {});
      }
    }
    throw err;
  }
}

module.exports = { createSale };
