const RecentActivity = require('../models/RecentActivity');

const MAX_PER_TYPE = 20;

async function recordActivity({ user, entityType, entityId, label, action = 'viewed' }) {
  try {
    const userId = user._id || user;
    await RecentActivity.findOneAndUpdate(
      { user: userId, entityType, entityId: String(entityId) },
      { $set: { label, action, accessedAt: new Date() } },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    const old = await RecentActivity.find({ user: userId, entityType }).sort({ accessedAt: -1 }).skip(MAX_PER_TYPE).select('_id');
    if (old.length) await RecentActivity.deleteMany({ _id: { $in: old.map((o) => o._id) } });
  } catch (e) {
    console.error('Activity record failed:', e.message);
  }
}

module.exports = { recordActivity };
