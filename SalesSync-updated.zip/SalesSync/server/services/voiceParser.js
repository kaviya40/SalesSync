/**
 * Pure (database-free) natural-language command parser for Voice-to-Transaction.
 * Understands English, Tanglish (Tamil in Latin letters) and common Tamil-script keywords.
 *
 * parseCommand(transcript, { products, context }) returns one of:
 *   { type: 'ACTION',    intent: 'ADD'|'REDUCE'|'SELL'|'QUERY', quantity, product }
 *   { type: 'SHOW_SALES', period: 'today'|'week'|'month' }
 *   { type: 'SHOW_LOW_STOCK' }
 *   { type: 'CLARIFY',   message, pending }
 *   { type: 'NOT_FOUND', message, phrase }
 *   { type: 'UNKNOWN',   message }
 * `context` = { lastProduct: {id,name}, pending: {...} } as returned by the previous call.
 */

const NUM_WORDS = {
  zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10,
  eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18,
  nineteen: 19, twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90,
  // Tanglish
  onnu: 1, ondru: 1, onru: 1, rendu: 2, irandu: 2, moonu: 3, munu: 3, naalu: 4, nalu: 4, anju: 5, aindhu: 5,
  aaru: 6, ezhu: 7, yezhu: 7, ettu: 8, ombadhu: 9, onbadhu: 9, pathu: 10, patthu: 10,
  // Tamil script
  'ஒன்று': 1, 'ஒண்ணு': 1, 'இரண்டு': 2, 'ரெண்டு': 2, 'மூன்று': 3, 'மூணு': 3, 'நான்கு': 4, 'நாலு': 4, 'ஐந்து': 5, 'அஞ்சு': 5,
  'ஆறு': 6, 'ஏழு': 7, 'எட்டு': 8, 'ஒன்பது': 9, 'ஒம்பது': 9, 'பத்து': 10,
};
const TENS = new Set(['twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety']);

const ORDINALS = { first: 1, second: 2, third: 3, fourth: 4, fifth: 5, last: -1 };

const STOP_WORDS = new Set([
  'to', 'the', 'of', 'from', 'in', 'on', 'at', 'for', 'a', 'an', 'and', 'my', 'me', 'please', 'pls', 'kindly', 'can', 'you', 'we', 'do', 'does', 'have', 'has', 'are', 'is', 'there', 'any', 'i', 'it', 'its', 's',
  'how', 'many', 'much', 'what', 'show', 'tell', 'check', 'give', 'get', 'stock', 'stocks', 'inventory', 'units', 'unit', 'pieces', 'piece', 'pcs', 'pc', 'nos', 'items', 'item', 'quantity', 'qty',
  'available', 'availability', 'left', 'remaining', 'now', 'currently', 'more', 'also', 'again', 'another', 'same', 'that', 'this', 'one', 'ones',
  // intent words
  'add', 'adding', 'added', 'increase', 'restock', 'purchase', 'purchased', 'received', 'receive', 'remove', 'reduce', 'decrease', 'deduct', 'minus', 'sell', 'sold', 'sale', 'sales', 'bill', 'billing',
  // Tanglish fillers
  'la', 'le', 'ku', 'kku', 'ah', 'a', 'pannu', 'panna', 'pannunga', 'pannuga', 'pannungal', 'panni', 'podu', 'podunga', 'poduga', 'vendum', 'venum', 'irukku', 'irukka', 'irukkaa', 'evvalavu', 'evlo', 'ethana', 'ethanai', 'enna', 'sollu', 'solluga', 'kaattu', 'kaatu', 'kaamunga', 'kaattunga',
  'serthu', 'sethu', 'serkkavum', 'serkka', 'sera', 'kurai', 'kuraikka', 'kuraii', 'vikka', 'vittu', 'vitru', 'vikkanum', 'vithen', 'vittuten',
  'இல்', 'ல', 'க்கு', 'ஐ', 'எத்தனை', 'எவ்வளவு', 'இருக்கு', 'இருக்கா', 'இருக்கிறது', 'சேர்', 'சேர்க்க', 'சேர்த்து', 'குறை', 'குறைக்க', 'விற்', 'விற்க', 'விற்று', 'விற்பனை', 'செய்', 'செய்யவும்', 'காட்டு', 'இன்று', 'ஸ்டாக்',
]);

const norm = (s) => String(s || '').toLowerCase().normalize('NFC').replace(/[^\p{L}\p{M}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim();

function singular(t) {
  if (/^\d+$/.test(t) || t.length <= 3) return t;
  if (t.endsWith('ies') && t.length > 4) return t.slice(0, -3) + 'y';
  if (/(sses|ches|shes|xes)$/.test(t)) return t.slice(0, -2);
  if (t.endsWith('s') && !t.endsWith('ss')) return t.slice(0, -1);
  return t;
}

const tokenize = (text) => norm(text).split(' ').filter(Boolean);

/* ---------- intent detection ---------- */

function detectIntent(text, tokens) {
  const has = (...words) => words.some((w) => tokens.includes(w));
  const starts = (...pre) => tokens.some((t) => pre.some((p) => t.startsWith(p)));
  const tamil = (...frag) => frag.some((f) => text.includes(f));

  const mentionsSales = has('sales') || tamil('விற்பனை');
  const showVerb = has('show', 'display', 'view', 'list', 'what', 'whats', 'get', 'tell', 'enna', 'kaattu', 'kaatu', 'kaamunga', 'kaattunga', 'report') || tamil('காட்டு', 'என்ன');
  if (mentionsSales && (showVerb || has('today', 'todays', 'week', 'month', 'indru', 'inniku', 'report', 'summary') || tamil('இன்று'))) {
    let period = 'today';
    if (has('week', 'weekly', 'vaaram') || tamil('வாரம்')) period = 'week';
    else if (has('month', 'monthly', 'maadham', 'maasam') || tamil('மாதம்')) period = 'month';
    return { intent: 'SHOW_SALES', period };
  }
  if (text.includes('low stock') || text.includes('out of stock') || text.includes('stock kammi') || tamil('குறைவான')) return { intent: 'SHOW_LOW_STOCK' };

  const add = has('add', 'adding', 'added', 'increase', 'restock', 'receive', 'received', 'purchase', 'purchased') || starts('sert', 'serk') || tamil('சேர்');
  const reduce = has('remove', 'reduce', 'decrease', 'deduct', 'minus') || starts('kurai') || tamil('குறை');
  const sell = has('sell', 'sold', 'sale', 'bill', 'billing') || starts('vikk', 'vitt', 'vitr', 'vith') || tamil('விற்');
  const mutation = [add && 'ADD', reduce && 'REDUCE', sell && 'SELL'].filter(Boolean);

  const strongQuery = /how many|how much|evvalavu|evlo|ethana|ethanai|stock status|check stock|stock check|stock enna|irukka|irukkaa/.test(text) || tamil('எத்தனை', 'எவ்வளவு', 'இருக்கா');
  if (strongQuery && mutation.length === 0) return { intent: 'QUERY' };
  if (mutation.length === 1) return { intent: mutation[0] };
  if (mutation.length > 1) return { intent: 'AMBIGUOUS', options: mutation };
  if (has('available', 'availability', 'left', 'remaining', 'irukku') || text.includes('in stock') || tamil('இருக்கு', 'இருக்கிறது')) return { intent: 'QUERY' };
  return { intent: null };
}

/* ---------- quantity ---------- */

/** Returns every number found as { value, indexes: [token indexes] } in order of appearance. */
function findNumbers(tokens) {
  const found = [];
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    if (/^\d+$/.test(t)) {
      found.push({ value: parseInt(t, 10), indexes: [i] });
    } else if (t in NUM_WORDS) {
      if (TENS.has(t) && tokens[i + 1] in NUM_WORDS && NUM_WORDS[tokens[i + 1]] >= 1 && NUM_WORDS[tokens[i + 1]] <= 9) {
        found.push({ value: NUM_WORDS[t] + NUM_WORDS[tokens[i + 1]], indexes: [i, i + 1] });
        i++;
      } else if (tokens[i + 1] === 'hundred' && NUM_WORDS[t] < 10) {
        found.push({ value: NUM_WORDS[t] * 100, indexes: [i, i + 1] });
        i++;
      } else {
        found.push({ value: NUM_WORDS[t], indexes: [i] });
      }
    } else if (t === 'hundred') {
      found.push({ value: 100, indexes: [i] });
    }
  }
  return found;
}

/* ---------- product matching ---------- */

function haystack(p) {
  const raw = [p.name, p.sku, p.color, p.size, p.category, ...(p.aliases || [])].filter(Boolean).join(' ');
  return tokenize(raw).map(singular);
}

function matchProducts(phraseTokens, products) {
  const q = phraseTokens.map(singular).filter(Boolean);
  if (q.length === 0) return [];
  const scored = [];
  for (const p of products) {
    const hay = haystack(p);
    const ok = q.every((qt) => hay.some((h) => h === qt || (qt.length >= 4 && h.startsWith(qt))));
    if (!ok) continue;
    const nameTokens = tokenize(p.name).map(singular);
    const exact = nameTokens.length === q.length && nameTokens.every((n) => q.includes(n)) ? 1 : 0;
    scored.push({ p, score: q.length + exact });
  }
  if (!scored.length) return [];
  const best = Math.max(...scored.map((s) => s.score));
  return scored.filter((s) => s.score === best).map((s) => s.p);
}

const describe = (p) => [p.name, p.color, p.size].filter(Boolean).join(' ');
const pid = (p) => String(p._id || p.id);
const slim = (p) => ({ id: pid(p), name: p.name, color: p.color, size: p.size, sku: p.sku, label: describe(p) });

function phraseFrom(tokens, skipIdx) {
  return tokens.filter((t, i) => !skipIdx.has(i) && !STOP_WORDS.has(t));
}

function clarifyChoice(intent, quantity, matches, phrase) {
  const shown = matches.slice(0, 6);
  const list = shown.map((p, i) => `${i + 1}) ${describe(p)}`).join(', ');
  return {
    type: 'CLARIFY',
    message: `I found ${matches.length} matches for "${phrase}": ${list}. Which one do you mean? You can say the colour/size or the number.`,
    pending: { needs: 'choice', intent, quantity, candidates: shown.map(slim) },
  };
}

/* ---------- pending-answer resolution ---------- */

function resolvePending(text, tokens, pending, products, intentInfo) {
  const byId = new Map(products.map((p) => [pid(p), p]));
  const numbers = findNumbers(tokens);

  if (pending.needs === 'quantity') {
    const n = numbers[0];
    const product = byId.get(pending.productId);
    if (!product) return { type: 'UNKNOWN', message: 'That product is no longer available. Please start again.' };
    if (!n || n.value < 1) return { type: 'CLARIFY', message: `How many ${product.name} should I ${verbFor(pending.intent)}? Please say a number.`, pending };
    return { type: 'ACTION', intent: pending.intent, quantity: n.value, product };
  }

  if (pending.needs === 'choice') {
    const cands = (pending.candidates || []).map((c) => byId.get(c.id)).filter(Boolean);
    let chosen = null;
    const ordinal = tokens.map((t) => ORDINALS[t]).find((v) => v !== undefined);
    if (ordinal) chosen = ordinal === -1 ? cands[cands.length - 1] : cands[ordinal - 1];
    else if (numbers.length === 1 && tokens.filter((t) => !STOP_WORDS.has(t) && !(t in NUM_WORDS) && !/^\d+$/.test(t)).length === 0) chosen = cands[numbers[0].value - 1];
    if (!chosen) {
      const phrase = tokens.filter((t) => !STOP_WORDS.has(t) && !/^\d+$/.test(t) && !(t in NUM_WORDS));
      const hits = matchProducts(phrase, cands);
      if (hits.length === 1) chosen = hits[0];
      else if (hits.length > 1) return clarifyChoice(pending.intent, pending.quantity, hits, phrase.join(' '));
    }
    if (!chosen) {
      return { type: 'CLARIFY', message: `I still couldn't tell which one. Options: ${cands.map((c, i) => `${i + 1}) ${describe(c)}`).join(', ')}. Say the colour, size or number.`, pending };
    }
    if (!pending.quantity) {
      return { type: 'CLARIFY', message: `How many ${describe(chosen)} should I ${verbFor(pending.intent)}?`, pending: { needs: 'quantity', intent: pending.intent, productId: pid(chosen) } };
    }
    return { type: 'ACTION', intent: pending.intent, quantity: pending.quantity, product: chosen };
  }

  if (pending.needs === 'product') {
    const phrase = tokens.filter((t) => !STOP_WORDS.has(t) && !/^\d+$/.test(t) && !(t in NUM_WORDS));
    const hits = matchProducts(phrase, products);
    if (hits.length === 1) return { type: 'ACTION', intent: pending.intent, quantity: pending.quantity, product: hits[0] };
    if (hits.length > 1) return clarifyChoice(pending.intent, pending.quantity, hits, phrase.join(' '));
    return { type: 'NOT_FOUND', phrase: phrase.join(' '), message: `I couldn't find "${phrase.join(' ')}". Please add the product first on the Products page.` };
  }
  return null;
}

function verbFor(intent) {
  return { ADD: 'add', REDUCE: 'remove', SELL: 'sell', QUERY: 'check' }[intent] || 'process';
}

/* ---------- main entry ---------- */

function parseCommand(transcript, { products = [], context = {} } = {}) {
  const text = norm(transcript);
  const tokens = text.split(' ').filter(Boolean);
  if (!tokens.length) return { type: 'UNKNOWN', message: "I didn't catch that. Please try again." };

  const info = detectIntent(text, tokens);

  // Answer to a previous clarification question (unless the user clearly started a new command)
  if (context.pending && !info.intent) {
    const resolved = resolvePending(text, tokens, context.pending, products, info);
    if (resolved) return resolved;
  }

  if (info.intent === 'SHOW_SALES') return { type: 'SHOW_SALES', period: info.period };
  if (info.intent === 'SHOW_LOW_STOCK') return { type: 'SHOW_LOW_STOCK' };
  if (info.intent === 'AMBIGUOUS') {
    return { type: 'CLARIFY', message: 'Do you want to add stock, remove stock, or sell? Please say the full command again.', pending: null };
  }
  if (!info.intent) {
    return { type: 'UNKNOWN', message: 'Sorry, I can add stock, remove stock, sell items, check availability or show sales. Try: "Sell 2 smartphones".' };
  }

  const intent = info.intent;
  const numbers = findNumbers(tokens);
  const needsQty = intent !== 'QUERY';
  const lastProduct = context.lastProduct ? products.find((p) => pid(p) === context.lastProduct.id) : null;

  // Try each number as the quantity until a product phrase matches (handles "iphone 15 sell 2")
  const attempts = needsQty && numbers.length ? numbers : [null];
  let lastPhrase = '';
  for (const n of attempts) {
    const skip = new Set(n ? n.indexes : []);
    const phraseTokens = phraseFrom(tokens, skip);
    const phrase = phraseTokens.join(' ');
    lastPhrase = phrase || lastPhrase;

    if (phraseTokens.length === 0) {
      // No product named: use conversation context ("sell 2 more", "how many are left")
      if (lastProduct) {
        if (needsQty && !n) return { type: 'CLARIFY', message: `How many ${describe(lastProduct)} should I ${verbFor(intent)}?`, pending: { needs: 'quantity', intent, productId: pid(lastProduct) } };
        return { type: 'ACTION', intent, quantity: n ? n.value : null, product: lastProduct };
      }
      if (needsQty && n) return { type: 'CLARIFY', message: `Which product should I ${verbFor(intent)} ${n.value} of?`, pending: { needs: 'product', intent, quantity: n.value } };
      if (!needsQty) return { type: 'CLARIFY', message: 'Which product do you want to check?', pending: { needs: 'product', intent: 'QUERY', quantity: null } };
      continue;
    }

    const matches = matchProducts(phraseTokens, products);
    if (matches.length === 0) continue;
    if (matches.length > 1) return clarifyChoice(intent, n ? n.value : null, matches, phrase);
    const product = matches[0];
    if (needsQty && !n) {
      return { type: 'CLARIFY', message: `How many ${describe(product)} should I ${verbFor(intent)}?`, pending: { needs: 'quantity', intent, productId: pid(product) } };
    }
    if (needsQty && n.value < 1) return { type: 'UNKNOWN', message: 'The quantity must be at least 1.' };
    return { type: 'ACTION', intent, quantity: n ? n.value : null, product };
  }

  if (lastPhrase) {
    return { type: 'NOT_FOUND', phrase: lastPhrase, message: `I couldn't find "${lastPhrase}" in your products. Please add it on the Products page first — I don't create products from voice commands.` };
  }
  return { type: 'UNKNOWN', message: 'I could not work out which product you meant. Please try again.' };
}

module.exports = { parseCommand, matchProducts, findNumbers, detectIntent, tokenize, describe, slim };
