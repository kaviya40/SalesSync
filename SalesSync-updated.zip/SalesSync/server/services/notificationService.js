const Notification = require('../models/Notification');

/** Create / resolve low-stock and out-of-stock notifications based on the product's current stock. */
async function syncStockNotification(product) {
  if (!product) return;
  let type = null;
  if (product.stock <= 0) type = 'OUT_OF_STOCK';
  else if (product.stock <= product.lowStockThreshold) type = 'LOW_STOCK';

  const resolveFilter = { product: product._id, resolved: false };
  if (type) resolveFilter.type = { $ne: type };
  await Notification.updateMany(resolveFilter, { $set: { resolved: true, resolvedAt: new Date() } });

  if (!type) return;
  const existing = await Notification.findOne({ product: product._id, type, resolved: false });
  if (existing) {
    existing.message = buildMessage(type, product);
    await existing.save();
    return;
  }
  await Notification.create({ type, product: product._id, message: buildMessage(type, product) });
}

function buildMessage(type, p) {
  const label = [p.name, p.color, p.size].filter(Boolean).join(' ');
  return type === 'OUT_OF_STOCK'
    ? `${label} is out of stock.`
    : `${label} is running low: ${p.stock} left (threshold ${p.lowStockThreshold}).`;
}

async function syncMany(products) {
  for (const p of products) {
    try {
      await syncStockNotification(p);
    } catch (e) {
      console.error('Notification sync failed:', e.message);
    }
  }
}

module.exports = { syncStockNotification, syncMany };
