const mongoose = require('mongoose');
const Product = require('../models/Product');
const InventoryTransaction = require('../models/InventoryTransaction');
const HttpError = require('../utils/HttpError');
const { supportsTransactions } = require('../config/db');
const { syncMany } = require('./notificationService');
const { recordActivity } = require('./activityService');
const { assertObjectId } = require('../utils/helpers');

/**
 * Runs `work(session)` inside a MongoDB transaction when the deployment supports it
 * (replica set / Atlas). Otherwise runs it with session = null; callers must then rely on
 * atomic conditional updates plus compensation (see saleService / adjustStock).
 */
async function withTransaction(work) {
  if (!supportsTransactions()) return work(null);
  const session = await mongoose.startSession();
  try {
    let result;
    await session.withTransaction(async () => {
      result = await work(session);
    });
    return result;
  } finally {
    await session.endSession();
  }
}

/**
 * Manually add or reduce stock for one product.
 * Reduction uses an atomic conditional update ({stock >= qty}) so stock can never go negative,
 * even with concurrent requests.
 */
async function adjustStock({ productId, type, quantity, reason, user, source = 'manual' }) {
  assertObjectId(productId, 'product id');
  if (!['ADD', 'REDUCE'].includes(type)) throw new HttpError(400, 'type must be ADD or REDUCE');
  const qty = Number(quantity);
  if (!Number.isInteger(qty) || qty < 1 || qty > 1000000) throw new HttpError(400, 'Quantity must be a whole number of at least 1');
  const delta = type === 'ADD' ? qty : -qty;

  let revert = null;
  try {
    const result = await withTransaction(async (session) => {
      const filter = { _id: productId, isActive: true };
      if (delta < 0) filter.stock = { $gte: qty };
      const after = await Product.findOneAndUpdate(filter, { $inc: { stock: delta } }, { new: true, session });
      if (!after) {
        const p = await Product.findById(productId).session(session);
        if (!p || !p.isActive) throw new HttpError(404, 'Product not found');
        throw new HttpError(409, `Insufficient stock for ${p.name}. Available: ${p.stock}, requested: ${qty}`);
      }
      if (!session) revert = { productId, delta: -delta };
      const [tx] = await InventoryTransaction.create(
        [{
          product: after._id,
          productName: after.name,
          type,
          quantityChange: delta,
          stockBefore: after.stock - delta,
          stockAfter: after.stock,
          reason,
          source,
          createdBy: user._id,
        }],
        { session }
      );
      return { product: after, transaction: tx };
    });
    await syncMany([result.product]);
    await recordActivity({ user, entityType: 'product', entityId: result.product._id, label: result.product.name, action: type === 'ADD' ? 'stock added' : 'stock reduced' });
    return result;
  } catch (err) {
    if (revert) await Product.updateOne({ _id: revert.productId }, { $inc: { stock: revert.delta } }).catch(() => {});
    throw err;
  }
}

module.exports = { withTransaction, adjustStock };
