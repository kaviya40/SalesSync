const Product = require('../models/Product');
const HttpError = require('../utils/HttpError');
const { parseCommand, describe, slim } = require('./voiceParser');
const { adjustStock } = require('./stockService');
const { createSale } = require('./saleService');
const { todaySummary, stockReport } = require('./reportService');

const money = (n) => `₹${Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
const CAN_MANAGE_STOCK = ['ADMIN', 'OWNER'];

/** Runs a voice command end-to-end: parse -> validate -> MongoDB operation -> response for the UI. */
async function handleVoiceCommand(transcript, context, user) {
  if (typeof transcript !== 'string' || !transcript.trim()) throw new HttpError(400, 'transcript is required');
  if (transcript.length > 300) throw new HttpError(400, 'Command is too long');

  const products = await Product.find({ isActive: true }).select('name sku color size category aliases stock price lowStockThreshold').limit(5000).lean();
  const parsed = parseCommand(transcript, { products, context: context || {} });
  const base = { transcript, refresh: [] };
  const ctx = (extra = {}) => ({ lastProduct: context?.lastProduct || null, pending: null, ...extra });

  switch (parsed.type) {
    case 'CLARIFY':
      return { ...base, success: true, type: 'CLARIFY', message: parsed.message, context: ctx({ pending: parsed.pending }) };
    case 'NOT_FOUND':
      return { ...base, success: false, type: 'NOT_FOUND', message: parsed.message, navigate: '/products', context: ctx() };
    case 'UNKNOWN':
      return { ...base, success: false, type: 'UNKNOWN', message: parsed.message, context: ctx() };
    case 'SHOW_SALES': {
      const s = await todaySummary(user, parsed.period);
      const label = { today: "Today's", week: 'Last 7 days', month: 'Last 30 days' }[parsed.period];
      return { ...base, success: true, type: 'SHOW_SALES', message: `${label} sales: ${s.orders} order${s.orders === 1 ? '' : 's'}, ${s.units} unit${s.units === 1 ? '' : 's'}, ${money(s.revenue)} revenue.`, data: s, navigate: '/sales', context: ctx() };
    }
    case 'SHOW_LOW_STOCK': {
      const r = await stockReport();
      const low = r.lowStock.map((p) => `${describe(p)} (${p.stock})`);
      const out = r.outOfStock.map((p) => describe(p));
      const parts = [];
      if (low.length) parts.push(`Low: ${low.slice(0, 5).join(', ')}`);
      if (out.length) parts.push(`Out of stock: ${out.slice(0, 5).join(', ')}`);
      return { ...base, success: true, type: 'SHOW_LOW_STOCK', message: parts.length ? parts.join('. ') + '.' : 'All products are above their low-stock levels.', navigate: '/notifications', context: ctx() };
    }
    case 'ACTION':
      return execute(parsed, user, base, ctx);
    default:
      return { ...base, success: false, type: 'UNKNOWN', message: 'Something went wrong understanding that command.', context: ctx() };
  }
}

async function execute(parsed, user, base, ctx) {
  const { intent, quantity, product } = parsed;
  const label = describe(product);
  const lastProduct = { id: String(product._id), name: label };

  try {
    if (intent === 'QUERY') {
      const fresh = await Product.findById(product._id).lean();
      const msg = fresh.stock === 0 ? `${label} is out of stock.` : `${fresh.stock} ${fresh.unit || 'pcs'} of ${label} available${fresh.stock <= fresh.lowStockThreshold ? ' (low stock)' : ''}.`;
      return { ...base, success: true, type: 'QUERY', intent, message: msg, data: { product: slim(fresh), stock: fresh.stock }, context: ctx({ lastProduct }) };
    }

    if (intent === 'SELL') {
      const { sale, products } = await createSale({ items: [{ productId: product._id, quantity }] }, user, 'voice');
      const left = products[0].stock;
      return { ...base, success: true, type: 'SELL', intent, message: `Sold ${quantity} × ${label} for ${money(sale.total)}. ${left} left in stock.`, data: { invoiceNumber: sale.invoiceNumber, total: sale.total, stock: left }, refresh: ['products', 'notifications', 'sales'], context: ctx({ lastProduct }) };
    }

    if (!CAN_MANAGE_STOCK.includes(user.role)) {
      return { ...base, success: false, type: 'FORBIDDEN', message: 'Only owners and admins can change stock levels.', context: ctx({ lastProduct }) };
    }
    const type = intent === 'ADD' ? 'ADD' : 'REDUCE';
    const { product: updated } = await adjustStock({ productId: product._id, type, quantity, reason: 'Voice command', user, source: 'voice' });
    return { ...base, success: true, type: intent, intent, message: `${type === 'ADD' ? 'Added' : 'Removed'} ${quantity} ${updated.unit || 'pcs'} ${type === 'ADD' ? 'to' : 'from'} ${label}. Stock is now ${updated.stock}.`, data: { stock: updated.stock }, refresh: ['products', 'notifications'], context: ctx({ lastProduct }) };
  } catch (err) {
    if (err instanceof HttpError) {
      return { ...base, success: false, type: 'ERROR', intent, message: err.message, context: ctx({ lastProduct }) };
    }
    throw err;
  }
}

module.exports = { handleVoiceCommand };
