const mongoose = require('mongoose');
const { env } = require('./env');

let transactionsSupported = false;

async function connectDB() {
  mongoose.set('strictQuery', true);
  await mongoose.connect(env.mongoUri, { serverSelectionTimeoutMS: 10000 });
  try {
    const hello = await mongoose.connection.db.admin().command({ hello: 1 });
    transactionsSupported = Boolean(hello.setName) || hello.msg === 'isdbgrid';
  } catch (e) {
    transactionsSupported = false;
  }
  console.log(`MongoDB connected (${mongoose.connection.name}). Transactions: ${transactionsSupported ? 'ENABLED' : 'not available - using atomic updates with compensating rollback'}`);
}

const supportsTransactions = () => transactionsSupported;

module.exports = { connectDB, supportsTransactions };
