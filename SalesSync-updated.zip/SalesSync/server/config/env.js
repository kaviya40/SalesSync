require('dotenv').config();

// MongoDB URI: either MONGODB_URI, or built from MONGO_USER / MONGO_PASSWORD / MONGO_HOST / MONGO_SRV / MONGO_DB
function buildMongoUri() {
  if (process.env.MONGODB_URI) return process.env.MONGODB_URI;
  const { MONGO_USER, MONGO_PASSWORD, MONGO_HOST, MONGO_SRV, MONGO_DB } = process.env;
  if (!MONGO_HOST) return undefined;
  const auth = MONGO_USER ? `${encodeURIComponent(MONGO_USER)}:${encodeURIComponent(MONGO_PASSWORD || '')}@` : '';
  const scheme = String(MONGO_SRV).toLowerCase() === 'true' ? 'mongodb+srv' : 'mongodb';
  return `${scheme}://${auth}${MONGO_HOST}/${MONGO_DB || 'salessync'}?retryWrites=true&w=majority`;
}

const env = {
  port: parseInt(process.env.PORT, 10) || 5000,
  nodeEnv: process.env.NODE_ENV || 'development',
  mongoUri: buildMongoUri(),
  jwtSecret: process.env.JWT_SECRET || process.env.SECRET_KEY,
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  clientOrigins: (process.env.CLIENT_ORIGIN || 'http://localhost:5173')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),
  googleClientId: process.env.GOOGLE_CLIENT_ID || '',
  reportTimezone: process.env.REPORT_TIMEZONE || 'Asia/Kolkata',
};

function validateEnv() {
  const problems = [];
  if (!env.mongoUri) problems.push('MongoDB is not configured (set MONGODB_URI, or MONGO_USER/MONGO_PASSWORD/MONGO_HOST/MONGO_SRV/MONGO_DB)');
  if (!env.jwtSecret || env.jwtSecret.length < 32) {
    problems.push('JWT_SECRET must be set and at least 32 characters long');
  }
  if (problems.length) {
    console.error('\nConfiguration error:\n - ' + problems.join('\n - '));
    console.error('\nCopy server/.env.example to server/.env and fill it in.\n');
    process.exit(1);
  }
}

module.exports = { env, validateEnv };
