const mongoose = require('mongoose');

const schema = new mongoose.Schema(
  {
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true, index: true },
    productName: String,
    type: { type: String, enum: ['ADD', 'REDUCE', 'SALE'], required: true },
    quantityChange: { type: Number, required: true }, // signed
    stockBefore: { type: Number, required: true },
    stockAfter: { type: Number, required: true },
    reason: { type: String, maxlength: 200 },
    sale: { type: mongoose.Schema.Types.ObjectId, ref: 'Sale' },
    source: { type: String, enum: ['manual', 'voice'], default: 'manual' },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

schema.index({ createdAt: -1 });

module.exports = mongoose.model('InventoryTransaction', schema);
