const mongoose = require('mongoose');

const schema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    entityType: { type: String, enum: ['product', 'sale', 'customer', 'report'], required: true },
    entityId: { type: String, required: true },
    label: { type: String, required: true },
    action: { type: String, default: 'viewed' },
    accessedAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

schema.index({ user: 1, entityType: 1, entityId: 1 }, { unique: true });
schema.index({ user: 1, accessedAt: -1 });

module.exports = mongoose.model('RecentActivity', schema);
