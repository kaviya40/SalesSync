const mongoose = require('mongoose');

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 120 },
    sku: { type: String, required: true, unique: true, trim: true, uppercase: true },
    category: { type: String, trim: true, default: 'General' },
    description: { type: String, trim: true, maxlength: 1000 },
    color: { type: String, trim: true, lowercase: true },
    size: { type: String, trim: true, lowercase: true },
    // Extra spoken names (Tamil / Tanglish / nicknames) used by voice matching
    aliases: [{ type: String, trim: true, lowercase: true }],
    price: { type: Number, required: true, min: 0 },
    costPrice: { type: Number, min: 0, default: 0 },
    stock: { type: Number, default: 0, min: 0 },
    lowStockThreshold: { type: Number, default: 5, min: 0 },
    unit: { type: String, default: 'pcs', trim: true },
    image: String,
    isActive: { type: Boolean, default: true },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

productSchema.index({ name: 'text', sku: 'text', category: 'text' });
productSchema.index({ isActive: 1, category: 1 });

module.exports = mongoose.model('Product', productSchema);
