const mongoose = require('mongoose');

const schema = new mongoose.Schema(
  {
    type: { type: String, enum: ['LOW_STOCK', 'OUT_OF_STOCK'], required: true },
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    message: { type: String, required: true },
    read: { type: Boolean, default: false },
    resolved: { type: Boolean, default: false },
    resolvedAt: Date,
  },
  { timestamps: true }
);

schema.index({ resolved: 1, createdAt: -1 });
schema.index({ product: 1, type: 1, resolved: 1 });

module.exports = mongoose.model('Notification', schema);
