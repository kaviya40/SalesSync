// Run with: npm run test:voice   (no database needed)
const assert = require('assert');
const { parseCommand } = require('../services/voiceParser');

// Test fixtures live ONLY in this test file (the application itself ships with no sample data).
const products = [
  { _id: 'p1', name: 'Shirt', color: 'blue', size: 'm', sku: 'SH-B-M', category: 'Clothing', aliases: ['sattai'] },
  { _id: 'p2', name: 'Shirt', color: 'red', size: 'l', sku: 'SH-R-L', category: 'Clothing', aliases: ['sattai'] },
  { _id: 'p3', name: 'Smartphone', sku: 'SP-1', category: 'Electronics', aliases: [] },
  { _id: 'p4', name: 'Charger', sku: 'CH-1', category: 'Electronics', aliases: [] },
  { _id: 'p5', name: 'iPhone 15', sku: 'IP-15', category: 'Electronics', aliases: [] },
];

let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };

t('sell 2 smartphones', () => {
  const r = parseCommand('Sell 2 smartphones.', { products });
  assert.deepStrictEqual([r.type, r.intent, r.quantity, r.product._id], ['ACTION', 'SELL', 2, 'p3']);
});
t('how many chargers are available', () => {
  const r = parseCommand('How many chargers are available?', { products });
  assert.deepStrictEqual([r.type, r.intent, r.product._id], ['ACTION', 'QUERY', 'p4']);
});
t('show today\'s sales', () => {
  const r = parseCommand("Show today's sales.", { products });
  assert.deepStrictEqual([r.type, r.period], ['SHOW_SALES', 'today']);
});
t('tanglish: blue shirt 5 sell pannu', () => {
  const r = parseCommand('Blue shirt 5 sell pannu', { products });
  assert.deepStrictEqual([r.type, r.intent, r.quantity, r.product._id], ['ACTION', 'SELL', 5, 'p1']);
});
t('tanglish: 10 shirt stock la add pannu is ambiguous between two shirts', () => {
  const r = parseCommand('10 shirt stock la add pannu', { products });
  assert.strictEqual(r.type, 'CLARIFY');
  assert.strictEqual(r.pending.candidates.length, 2);
  assert.strictEqual(r.pending.quantity, 10);
});
t('follow-up "blue" resolves the clarification', () => {
  const first = parseCommand('Add 10 shirts to stock', { products });
  const r = parseCommand('the blue one', { products, context: { pending: first.pending } });
  assert.deepStrictEqual([r.type, r.intent, r.quantity, r.product._id], ['ACTION', 'ADD', 10, 'p1']);
});
t('follow-up "second" resolves the clarification', () => {
  const first = parseCommand('Sell 3 shirts', { products });
  const r = parseCommand('second one', { products, context: { pending: first.pending } });
  assert.deepStrictEqual([r.intent, r.quantity, r.product._id], ['SELL', 3, 'p2']);
});
t('missing quantity asks, then number answers', () => {
  const first = parseCommand('Sell smartphone', { products });
  assert.strictEqual(first.type, 'CLARIFY');
  const r = parseCommand('four', { products, context: { pending: first.pending } });
  assert.deepStrictEqual([r.type, r.intent, r.quantity, r.product._id], ['ACTION', 'SELL', 4, 'p3']);
});
t('context: "add 5 more" uses last product', () => {
  const r = parseCommand('add 5 more', { products, context: { lastProduct: { id: 'p3', name: 'Smartphone' } } });
  assert.deepStrictEqual([r.type, r.intent, r.quantity, r.product._id], ['ACTION', 'ADD', 5, 'p3']);
});
t('context: "how many are left"', () => {
  const r = parseCommand('how many are left', { products, context: { lastProduct: { id: 'p4', name: 'Charger' } } });
  assert.strictEqual(r.product._id, 'p4');
});
t('unknown product is never auto-created', () => {
  const r = parseCommand('Add 10 laptops to stock', { products });
  assert.strictEqual(r.type, 'NOT_FOUND');
  assert.ok(/add it/i.test(r.message));
});
t('number inside product name: iphone 15 sell 2', () => {
  const r = parseCommand('iphone 15 sell 2', { products });
  assert.deepStrictEqual([r.type, r.quantity, r.product._id], ['ACTION', 2, 'p5']);
});
t('alias (tanglish product name) works', () => {
  const r = parseCommand('2 sattai sell pannu', { products });
  assert.strictEqual(r.type, 'CLARIFY'); // two shirts share the alias
});
t('number words and compound numbers', () => {
  const r = parseCommand('add twenty five chargers', { products });
  assert.strictEqual(r.quantity, 25);
});
t('tanglish number words', () => {
  const r = parseCommand('charger anju sell pannu', { products });
  assert.deepStrictEqual([r.intent, r.quantity], ['SELL', 5]);
});
t('tamil script verb', () => {
  const r = parseCommand('smartphone 3 விற்க', { products });
  assert.deepStrictEqual([r.intent, r.quantity, r.product._id], ['SELL', 3, 'p3']);
});
t('gibberish', () => {
  assert.strictEqual(parseCommand('hello world', { products }).type, 'UNKNOWN');
});
console.log(`\n${n} parser tests passed`);
