/**
 * Creates a user directly in MongoDB. This is the secure way to create the FIRST admin
 * (public registration only ever creates STAFF users).
 *
 * Usage (Windows CMD, from the server folder):
 *   npm run create-user -- --name "Asha Admin" --email asha@example.com --role ADMIN
 * You will be prompted for the password (input hidden), or you can set SALESSYNC_PASSWORD
 * in the environment to run non-interactively.
 */
const readline = require('readline');
const mongoose = require('mongoose');
const { env, validateEnv } = require('../config/env');
validateEnv();
const User = require('../models/User');
const { ROLES } = require('../models/User');
const { str, email, password } = require('../validators');

function arg(name) {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 ? process.argv[i + 1] : undefined;
}

function askHidden(question) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    rl._writeToOutput = (s) => { if (s.includes(question)) rl.output.write(s); };
    rl.question(question, (answer) => { rl.close(); process.stdout.write('\n'); resolve(answer); });
  });
}

(async () => {
  try {
    const role = (arg('role') || 'STAFF').toUpperCase();
    if (!ROLES.includes(role)) throw new Error(`Role must be one of ${ROLES.join(', ')}`);
    const data = { name: str(arg('name'), 'Name', { min: 2, max: 80 }), email: email(arg('email')), role };
    const plain = process.env.SALESSYNC_PASSWORD || (await askHidden(`Password for ${data.email}: `));
    data.password = password(plain);

    await mongoose.connect(env.mongoUri, { serverSelectionTimeoutMS: 10000 });
    if (await User.findOne({ email: data.email })) throw new Error('A user with this email already exists');
    const user = await User.create(data);
    console.log(`Created ${user.role} user ${user.email} (id ${user._id})`);
  } catch (err) {
    console.error('Error:', err.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
})();
