const { OAuth2Client } = require('google-auth-library');
const User = require('../models/User');
const HttpError = require('../utils/HttpError');
const asyncHandler = require('../utils/asyncHandler');
const { env } = require('../config/env');
const { signToken } = require('../middleware/auth');
const { validateRegister, validateLogin } = require('../validators');

const googleClient = env.googleClientId ? new OAuth2Client(env.googleClientId) : null;
const session = (user) => ({ success: true, token: signToken(user), user: user.toSafeJSON() });

// Public registration always creates a STAFF user. Only an ADMIN can create OWNER/ADMIN accounts.
exports.register = asyncHandler(async (req, res) => {
  const { name, email, password } = validateRegister(req.body);
  if (await User.findOne({ email })) throw new HttpError(409, 'An account with this email already exists');
  const user = await User.create({ name, email, password, role: 'STAFF' });
  res.status(201).json(session(user));
});

exports.login = asyncHandler(async (req, res) => {
  const { email, password } = validateLogin(req.body);
  const user = await User.findOne({ email }).select('+password');
  // Same message for unknown email / wrong password to avoid account enumeration
  if (!user || !(await user.comparePassword(password))) throw new HttpError(401, 'Invalid email or password');
  if (!user.isActive) throw new HttpError(403, 'This account has been disabled');
  user.lastLoginAt = new Date();
  await user.save();
  res.json(session(user));
});

exports.google = asyncHandler(async (req, res) => {
  if (!googleClient) throw new HttpError(501, 'Google login is not configured on the server (set GOOGLE_CLIENT_ID)');
  const credential = req.body.credential;
  if (!credential || typeof credential !== 'string') throw new HttpError(400, 'Google credential is required');

  let payload;
  try {
    const ticket = await googleClient.verifyIdToken({ idToken: credential, audience: env.googleClientId });
    payload = ticket.getPayload();
  } catch (e) {
    throw new HttpError(401, 'Google sign-in could not be verified');
  }
  if (!payload.email || !payload.email_verified) throw new HttpError(401, 'Google account email is not verified');

  const email = payload.email.toLowerCase();
  let user = await User.findOne({ email });
  if (user) {
    if (!user.isActive) throw new HttpError(403, 'This account has been disabled');
    if (!user.googleId) user.googleId = payload.sub;
    if (!user.avatar && payload.picture) user.avatar = payload.picture;
  } else {
    user = new User({ name: payload.name || email.split('@')[0], email, googleId: payload.sub, avatar: payload.picture, authProvider: 'google', role: 'STAFF' });
  }
  user.lastLoginAt = new Date();
  await user.save();
  res.json(session(user));
});

exports.me = asyncHandler(async (req, res) => {
  res.json({ success: true, user: req.user.toSafeJSON() });
});
