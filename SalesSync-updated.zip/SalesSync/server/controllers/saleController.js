const Sale = require('../models/Sale');
const HttpError = require('../utils/HttpError');
const asyncHandler = require('../utils/asyncHandler');
const { createSale } = require('../services/saleService');
const { recordActivity } = require('../services/activityService');
const { assertObjectId, pageParams } = require('../utils/helpers');

exports.create = asyncHandler(async (req, res) => {
  const { sale, products } = await createSale(req.body, req.user, 'manual');
  res.status(201).json({ success: true, sale, stock: products.map((p) => ({ productId: p._id, stock: p.stock })) });
});

exports.list = asyncHandler(async (req, res) => {
  const { page, limit, skip } = pageParams(req.query);
  const filter = {};
  if (req.user.role === 'STAFF') filter.createdBy = req.user._id; // staff only see their own sales
  if (req.query.customer) filter.customer = assertObjectId(req.query.customer, 'customer id');
  if (req.query.from || req.query.to) {
    filter.createdAt = {};
    if (req.query.from) filter.createdAt.$gte = new Date(req.query.from);
    if (req.query.to) {
      const to = new Date(req.query.to);
      to.setHours(23, 59, 59, 999);
      filter.createdAt.$lte = to;
    }
    if (Object.values(filter.createdAt).some((d) => Number.isNaN(d.getTime()))) throw new HttpError(400, 'Invalid date filter');
  }
  const [items, total] = await Promise.all([
    Sale.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit).populate('createdBy', 'name'),
    Sale.countDocuments(filter),
  ]);
  res.json({ success: true, items, total, page, pages: Math.ceil(total / limit) });
});

exports.get = asyncHandler(async (req, res) => {
  assertObjectId(req.params.id, 'sale id');
  const filter = { _id: req.params.id };
  if (req.user.role === 'STAFF') filter.createdBy = req.user._id;
  const sale = await Sale.findOne(filter).populate('createdBy', 'name');
  if (!sale) throw new HttpError(404, 'Sale not found');
  recordActivity({ user: req.user, entityType: 'sale', entityId: sale._id, label: sale.invoiceNumber });
  res.json({ success: true, sale });
});
