const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Product = require('../models/Product');
const Notification = require('../models/Notification');
const InventoryTransaction = require('../models/InventoryTransaction');
const HttpError = require('../utils/HttpError');
const asyncHandler = require('../utils/asyncHandler');
const { assertObjectId, escapeRegex, pageParams } = require('../utils/helpers');
const { validateProduct } = require('../validators');
const { syncStockNotification } = require('../services/notificationService');
const { recordActivity } = require('../services/activityService');

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
const removeImage = (url) => {
  if (!url || !url.startsWith('/uploads/')) return;
  fs.unlink(path.join(UPLOAD_DIR, path.basename(url)), () => {});
};
const genSku = () => `SKU-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
const ci = (v) => new RegExp(`^${escapeRegex(v)}$`, 'i');

async function assertNoDuplicate(data, excludeId) {
  if (!data.name) return;
  const f = { isActive: true, name: ci(data.name), color: data.color ? ci(data.color) : { $in: [null, ''] }, size: data.size ? ci(data.size) : { $in: [null, ''] } };
  if (excludeId) f._id = { $ne: excludeId };
  if (await Product.findOne(f)) throw new HttpError(409, 'A product with the same name, colour and size already exists');
}

exports.list = asyncHandler(async (req, res) => {
  const { page, limit, skip } = pageParams(req.query);
  const { q, category, stockStatus, minPrice, maxPrice, sort = 'name', order = 'asc' } = req.query;
  const filter = { isActive: true };
  if (q) {
    const rx = new RegExp(escapeRegex(q), 'i');
    filter.$or = [{ name: rx }, { sku: rx }, { category: rx }, { color: rx }, { size: rx }, { aliases: rx }];
  }
  if (category) filter.category = category;
  if (minPrice || maxPrice) filter.price = { ...(minPrice && { $gte: Number(minPrice) }), ...(maxPrice && { $lte: Number(maxPrice) }) };
  if (stockStatus === 'out') filter.stock = 0;
  else if (stockStatus === 'low') Object.assign(filter, { stock: { $gt: 0 }, $expr: { $lte: ['$stock', '$lowStockThreshold'] } });
  else if (stockStatus === 'in') filter.$expr = { $gt: ['$stock', '$lowStockThreshold'] };

  const sortField = ['name', 'price', 'stock', 'createdAt', 'category'].includes(sort) ? sort : 'name';
  const [items, total] = await Promise.all([
    Product.find(filter).sort({ [sortField]: order === 'desc' ? -1 : 1, _id: 1 }).skip(skip).limit(limit),
    Product.countDocuments(filter),
  ]);
  res.json({ success: true, items, total, page, pages: Math.ceil(total / limit) });
});

exports.categories = asyncHandler(async (req, res) => {
  const items = await Product.distinct('category', { isActive: true });
  res.json({ success: true, items: items.filter(Boolean).sort() });
});

exports.get = asyncHandler(async (req, res) => {
  assertObjectId(req.params.id, 'product id');
  const product = await Product.findOne({ _id: req.params.id, isActive: true });
  if (!product) throw new HttpError(404, 'Product not found');
  const history = await InventoryTransaction.find({ product: product._id }).sort({ createdAt: -1 }).limit(10).populate('createdBy', 'name');
  recordActivity({ user: req.user, entityType: 'product', entityId: product._id, label: product.name });
  res.json({ success: true, product, history });
});

exports.create = asyncHandler(async (req, res) => {
  const data = validateProduct(req.body);
  try {
    await assertNoDuplicate(data);
    const opening = data.stock || 0;
    const product = await Product.create({ ...data, sku: data.sku || genSku(), stock: opening, image: req.file ? `/uploads/${req.file.filename}` : undefined, createdBy: req.user._id });
    if (opening > 0) {
      await InventoryTransaction.create({ product: product._id, productName: product.name, type: 'ADD', quantityChange: opening, stockBefore: 0, stockAfter: opening, reason: 'Opening stock', createdBy: req.user._id });
    }
    await syncStockNotification(product);
    recordActivity({ user: req.user, entityType: 'product', entityId: product._id, label: product.name, action: 'created' });
    res.status(201).json({ success: true, product });
  } catch (err) {
    if (req.file) removeImage(`/uploads/${req.file.filename}`);
    throw err;
  }
});

exports.update = asyncHandler(async (req, res) => {
  assertObjectId(req.params.id, 'product id');
  try {
    const product = await Product.findOne({ _id: req.params.id, isActive: true });
    if (!product) throw new HttpError(404, 'Product not found');
    const data = validateProduct(req.body, true);
    delete data.stock; // stock only changes through inventory adjustments / sales
    await assertNoDuplicate({ name: data.name ?? product.name, color: data.color ?? product.color, size: data.size ?? product.size }, product._id);
    Object.assign(product, data);
    if (req.body.color === '') product.color = undefined;
    if (req.body.size === '') product.size = undefined;
    const oldImage = product.image;
    if (req.file) product.image = `/uploads/${req.file.filename}`;
    await product.save();
    if (req.file) removeImage(oldImage);
    await syncStockNotification(product);
    recordActivity({ user: req.user, entityType: 'product', entityId: product._id, label: product.name, action: 'updated' });
    res.json({ success: true, product });
  } catch (err) {
    if (req.file) removeImage(`/uploads/${req.file.filename}`);
    throw err;
  }
});

// Soft delete keeps historical sales and inventory records intact
exports.remove = asyncHandler(async (req, res) => {
  assertObjectId(req.params.id, 'product id');
  const product = await Product.findOneAndUpdate({ _id: req.params.id, isActive: true }, { isActive: false }, { new: true });
  if (!product) throw new HttpError(404, 'Product not found');
  await Notification.updateMany({ product: product._id, resolved: false }, { resolved: true, resolvedAt: new Date() });
  res.json({ success: true, message: 'Product deleted' });
});
