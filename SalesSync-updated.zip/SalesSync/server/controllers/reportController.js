const asyncHandler = require('../utils/asyncHandler');
const reports = require('../services/reportService');
const { recordActivity } = require('../services/activityService');

exports.sales = asyncHandler(async (req, res) => {
  const period = ['daily', 'weekly', 'monthly'].includes(req.query.period) ? req.query.period : 'daily';
  const data = await reports.salesReport(period, req.user);
  recordActivity({ user: req.user, entityType: 'report', entityId: `sales-${period}`, label: `${period[0].toUpperCase() + period.slice(1)} sales report` });
  res.json({ success: true, ...data });
});

exports.topProducts = asyncHandler(async (req, res) => {
  const days = Math.min(Math.max(parseInt(req.query.days, 10) || 30, 1), 365);
  const items = await reports.topProducts(days, req.user, 10);
  recordActivity({ user: req.user, entityType: 'report', entityId: 'top-products', label: 'Top-selling products' });
  res.json({ success: true, days, items });
});

exports.stock = asyncHandler(async (req, res) => {
  const data = await reports.stockReport();
  recordActivity({ user: req.user, entityType: 'report', entityId: 'stock', label: 'Stock report' });
  res.json({ success: true, ...data });
});

exports.overview = asyncHandler(async (req, res) => {
  res.json({ success: true, ...(await reports.overview(req.user)) });
});
