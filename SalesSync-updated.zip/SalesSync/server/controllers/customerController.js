const Customer = require('../models/Customer');
const Sale = require('../models/Sale');
const HttpError = require('../utils/HttpError');
const asyncHandler = require('../utils/asyncHandler');
const { assertObjectId, escapeRegex, pageParams } = require('../utils/helpers');
const { validateCustomer } = require('../validators');
const { recordActivity } = require('../services/activityService');

exports.list = asyncHandler(async (req, res) => {
  const { page, limit, skip } = pageParams(req.query);
  const filter = { isActive: true };
  if (req.query.q) {
    const rx = new RegExp(escapeRegex(req.query.q), 'i');
    filter.$or = [{ name: rx }, { phone: rx }, { email: rx }];
  }
  const [items, total] = await Promise.all([Customer.find(filter).sort({ name: 1 }).skip(skip).limit(limit), Customer.countDocuments(filter)]);
  res.json({ success: true, items, total, page, pages: Math.ceil(total / limit) });
});

exports.get = asyncHandler(async (req, res) => {
  assertObjectId(req.params.id, 'customer id');
  const customer = await Customer.findOne({ _id: req.params.id, isActive: true });
  if (!customer) throw new HttpError(404, 'Customer not found');
  const salesFilter = { customer: customer._id };
  if (req.user.role === 'STAFF') salesFilter.createdBy = req.user._id;
  const sales = await Sale.find(salesFilter).sort({ createdAt: -1 }).limit(10).select('invoiceNumber total createdAt');
  recordActivity({ user: req.user, entityType: 'customer', entityId: customer._id, label: customer.name });
  res.json({ success: true, customer, sales });
});

exports.create = asyncHandler(async (req, res) => {
  const customer = await Customer.create({ ...validateCustomer(req.body), createdBy: req.user._id });
  recordActivity({ user: req.user, entityType: 'customer', entityId: customer._id, label: customer.name, action: 'created' });
  res.status(201).json({ success: true, customer });
});

exports.update = asyncHandler(async (req, res) => {
  assertObjectId(req.params.id, 'customer id');
  const customer = await Customer.findOneAndUpdate({ _id: req.params.id, isActive: true }, validateCustomer(req.body, true), { new: true, runValidators: true });
  if (!customer) throw new HttpError(404, 'Customer not found');
  recordActivity({ user: req.user, entityType: 'customer', entityId: customer._id, label: customer.name, action: 'updated' });
  res.json({ success: true, customer });
});

exports.remove = asyncHandler(async (req, res) => {
  assertObjectId(req.params.id, 'customer id');
  const c = await Customer.findOneAndUpdate({ _id: req.params.id, isActive: true }, { isActive: false });
  if (!c) throw new HttpError(404, 'Customer not found');
  res.json({ success: true, message: 'Customer deleted' });
});
