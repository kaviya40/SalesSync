const asyncHandler = require('../utils/asyncHandler');
const { handleVoiceCommand } = require('../services/voiceService');

exports.command = asyncHandler(async (req, res) => {
  const result = await handleVoiceCommand(req.body.transcript, req.body.context, req.user);
  res.json(result);
});
