const Notification = require('../models/Notification');
const HttpError = require('../utils/HttpError');
const asyncHandler = require('../utils/asyncHandler');
const { assertObjectId } = require('../utils/helpers');

exports.list = asyncHandler(async (req, res) => {
  const filter = { resolved: false };
  if (req.query.unread === 'true') filter.read = false;
  const [items, unread] = await Promise.all([
    Notification.find(filter).sort({ createdAt: -1 }).limit(100).populate('product', 'name color size stock lowStockThreshold'),
    Notification.countDocuments({ resolved: false, read: false }),
  ]);
  res.json({ success: true, items, unread });
});

exports.markRead = asyncHandler(async (req, res) => {
  assertObjectId(req.params.id, 'notification id');
  const n = await Notification.findByIdAndUpdate(req.params.id, { read: true }, { new: true });
  if (!n) throw new HttpError(404, 'Notification not found');
  res.json({ success: true, notification: n });
});

exports.markAllRead = asyncHandler(async (req, res) => {
  await Notification.updateMany({ resolved: false, read: false }, { read: true });
  res.json({ success: true });
});
