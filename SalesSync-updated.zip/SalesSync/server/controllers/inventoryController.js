const InventoryTransaction = require('../models/InventoryTransaction');
const asyncHandler = require('../utils/asyncHandler');
const { adjustStock } = require('../services/stockService');
const { pageParams, assertObjectId } = require('../utils/helpers');
const { str } = require('../validators');

exports.adjust = asyncHandler(async (req, res) => {
  const { productId, type, quantity } = req.body;
  const reason = str(req.body.reason, 'Reason', { max: 200, required: false });
  const { product, transaction } = await adjustStock({ productId, type, quantity, reason, user: req.user });
  res.status(201).json({ success: true, product, transaction });
});

exports.transactions = asyncHandler(async (req, res) => {
  const { page, limit, skip } = pageParams(req.query);
  const filter = {};
  if (req.query.product) filter.product = assertObjectId(req.query.product, 'product id');
  if (['ADD', 'REDUCE', 'SALE'].includes(req.query.type)) filter.type = req.query.type;
  const [items, total] = await Promise.all([
    InventoryTransaction.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit).populate('createdBy', 'name'),
    InventoryTransaction.countDocuments(filter),
  ]);
  res.json({ success: true, items, total, page, pages: Math.ceil(total / limit) });
});
