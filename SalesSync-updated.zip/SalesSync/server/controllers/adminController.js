const User = require('../models/User');
const Product = require('../models/Product');
const Sale = require('../models/Sale');
const Customer = require('../models/Customer');
const HttpError = require('../utils/HttpError');
const asyncHandler = require('../utils/asyncHandler');
const { assertObjectId, escapeRegex, pageParams } = require('../utils/helpers');
const { str, email, password } = require('../validators');

exports.stats = asyncHandler(async (req, res) => {
  const [users, byRole, products, customers, sales, revenue] = await Promise.all([
    User.countDocuments(),
    User.aggregate([{ $group: { _id: '$role', count: { $sum: 1 } } }]),
    Product.countDocuments({ isActive: true }),
    Customer.countDocuments({ isActive: true }),
    Sale.countDocuments(),
    Sale.aggregate([{ $group: { _id: null, total: { $sum: '$total' } } }]),
  ]);
  res.json({ success: true, stats: { users, byRole: Object.fromEntries(byRole.map((r) => [r._id, r.count])), products, customers, sales, revenue: revenue[0]?.total || 0 } });
});

exports.listUsers = asyncHandler(async (req, res) => {
  const { page, limit, skip } = pageParams(req.query, 50);
  const filter = {};
  if (req.query.role) filter.role = req.query.role;
  if (req.query.q) {
    const rx = new RegExp(escapeRegex(req.query.q), 'i');
    filter.$or = [{ name: rx }, { email: rx }];
  }
  const [items, total] = await Promise.all([User.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit), User.countDocuments(filter)]);
  res.json({ success: true, items: items.map((u) => ({ ...u.toSafeJSON(), lastLoginAt: u.lastLoginAt })), total, page, pages: Math.ceil(total / limit) });
});

exports.createUser = asyncHandler(async (req, res) => {
  const b = req.body;
  const role = ['ADMIN', 'OWNER', 'STAFF'].includes(b.role) ? b.role : null;
  if (!role) throw new HttpError(400, 'Role must be ADMIN, OWNER or STAFF');
  const data = { name: str(b.name, 'Name', { min: 2, max: 80 }), email: email(b.email), password: password(b.password), role };
  if (await User.findOne({ email: data.email })) throw new HttpError(409, 'An account with this email already exists');
  const user = await User.create(data);
  res.status(201).json({ success: true, user: user.toSafeJSON() });
});

exports.updateUser = asyncHandler(async (req, res) => {
  assertObjectId(req.params.id, 'user id');
  const user = await User.findById(req.params.id);
  if (!user) throw new HttpError(404, 'User not found');
  const { role, isActive } = req.body;
  const isSelf = String(user._id) === String(req.user._id);

  if (role !== undefined) {
    if (!['ADMIN', 'OWNER', 'STAFF'].includes(role)) throw new HttpError(400, 'Invalid role');
    if (isSelf && role !== 'ADMIN') throw new HttpError(400, 'You cannot remove your own admin role');
    user.role = role;
  }
  if (isActive !== undefined) {
    if (isSelf && !isActive) throw new HttpError(400, 'You cannot disable your own account');
    user.isActive = Boolean(isActive);
  }
  await user.save();
  res.json({ success: true, user: user.toSafeJSON() });
});
