const RecentActivity = require('../models/RecentActivity');
const Product = require('../models/Product');
const Sale = require('../models/Sale');
const Customer = require('../models/Customer');
const HttpError = require('../utils/HttpError');
const asyncHandler = require('../utils/asyncHandler');
const { assertObjectId } = require('../utils/helpers');
const { recordActivity } = require('../services/activityService');

const TYPES = ['product', 'sale', 'customer', 'report'];

exports.list = asyncHandler(async (req, res) => {
  const filter = { user: req.user._id };
  if (TYPES.includes(req.query.type)) filter.entityType = req.query.type;
  const limit = Math.min(parseInt(req.query.limit, 10) || 20, 50);
  const items = await RecentActivity.find(filter).sort({ accessedAt: -1 }).limit(limit);
  res.json({ success: true, items });
});

// Lets the UI record that a record was opened; label is derived from the database, not the client.
exports.record = asyncHandler(async (req, res) => {
  const { entityType, entityId } = req.body;
  if (!TYPES.includes(entityType)) throw new HttpError(400, 'Invalid entityType');
  let label;
  if (entityType === 'report') {
    if (!/^[a-z-]{3,40}$/.test(String(entityId))) throw new HttpError(400, 'Invalid report id');
    label = `${String(entityId).replace(/-/g, ' ')} report`;
  } else {
    assertObjectId(entityId, 'entity id');
    const model = { product: Product, sale: Sale, customer: Customer }[entityType];
    const doc = await model.findById(entityId);
    if (!doc) throw new HttpError(404, 'Record not found');
    label = doc.name || doc.invoiceNumber;
  }
  await recordActivity({ user: req.user, entityType, entityId, label });
  res.status(201).json({ success: true });
});
