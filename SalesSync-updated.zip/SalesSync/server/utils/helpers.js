const mongoose = require('mongoose');
const HttpError = require('./HttpError');

const round2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
const escapeRegex = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function assertObjectId(id, label = 'id') {
  if (!mongoose.Types.ObjectId.isValid(id)) throw new HttpError(400, `Invalid ${label}`);
  return id;
}

function pageParams(query, defaultLimit = 20) {
  const page = Math.max(parseInt(query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(query.limit, 10) || defaultLimit, 1), 100);
  return { page, limit, skip: (page - 1) * limit };
}

module.exports = { round2, escapeRegex, assertObjectId, pageParams };
