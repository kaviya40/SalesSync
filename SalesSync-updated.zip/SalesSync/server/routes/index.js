const express = require('express');
const rateLimit = require('express-rate-limit');
const { protect, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');

const auth = require('../controllers/authController');
const admin = require('../controllers/adminController');
const products = require('../controllers/productController');
const inventory = require('../controllers/inventoryController');
const sales = require('../controllers/saleController');
const customers = require('../controllers/customerController');
const reports = require('../controllers/reportController');
const notifications = require('../controllers/notificationController');
const recent = require('../controllers/recentController');
const voice = require('../controllers/voiceController');

const router = express.Router();
const MANAGERS = ['ADMIN', 'OWNER'];
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false, message: { success: false, message: 'Too many attempts. Try again in a few minutes.' } });

router.get('/health', (req, res) => res.json({ success: true, status: 'ok' }));

// Auth
router.post('/auth/register', authLimiter, auth.register);
router.post('/auth/login', authLimiter, auth.login);
router.post('/auth/google', authLimiter, auth.google);
router.get('/auth/me', protect, auth.me);

// Everything below requires a valid JWT
router.use(protect);

// Admin only
router.get('/admin/stats', authorize('ADMIN'), admin.stats);
router.get('/admin/users', authorize('ADMIN'), admin.listUsers);
router.post('/admin/users', authorize('ADMIN'), admin.createUser);
router.patch('/admin/users/:id', authorize('ADMIN'), admin.updateUser);

// Products
router.get('/products', products.list);
router.get('/products/categories', products.categories);
router.get('/products/:id', products.get);
router.post('/products', authorize(...MANAGERS), upload.single('image'), products.create);
router.put('/products/:id', authorize(...MANAGERS), upload.single('image'), products.update);
router.delete('/products/:id', authorize(...MANAGERS), products.remove);

// Inventory
router.post('/inventory/adjust', authorize(...MANAGERS), inventory.adjust);
router.get('/inventory/transactions', inventory.transactions);

// Sales
router.post('/sales', sales.create);
router.get('/sales', sales.list);
router.get('/sales/:id', sales.get);

// Customers
router.get('/customers', customers.list);
router.get('/customers/:id', customers.get);
router.post('/customers', customers.create);
router.put('/customers/:id', customers.update);
router.delete('/customers/:id', authorize(...MANAGERS), customers.remove);

// Reports
router.get('/reports/overview', reports.overview);
router.get('/reports/sales', reports.sales);
router.get('/reports/top-products', reports.topProducts);
router.get('/reports/stock', authorize(...MANAGERS), reports.stock);

// Notifications, recent activity, voice
router.get('/notifications', notifications.list);
router.patch('/notifications/read-all', notifications.markAllRead);
router.patch('/notifications/:id/read', notifications.markRead);
router.get('/recent', recent.list);
router.post('/recent', recent.record);
router.post('/voice/command', voice.command);

module.exports = router;
