const HttpError = require('../utils/HttpError');

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function str(v, label, { min = 1, max = 200, required = true } = {}) {
  if (v === undefined || v === null || v === '') {
    if (required) throw new HttpError(400, `${label} is required`);
    return undefined;
  }
  const s = String(v).trim();
  if (s.length < min) throw new HttpError(400, `${label} must be at least ${min} characters`);
  if (s.length > max) throw new HttpError(400, `${label} must be at most ${max} characters`);
  return s;
}

function num(v, label, { min = 0, max = 1e9, integer = false, required = true } = {}) {
  if (v === undefined || v === null || v === '') {
    if (required) throw new HttpError(400, `${label} is required`);
    return undefined;
  }
  const n = Number(v);
  if (!Number.isFinite(n)) throw new HttpError(400, `${label} must be a number`);
  if (integer && !Number.isInteger(n)) throw new HttpError(400, `${label} must be a whole number`);
  if (n < min || n > max) throw new HttpError(400, `${label} must be between ${min} and ${max}`);
  return n;
}

function email(v, label = 'Email', required = true) {
  const s = str(v, label, { max: 150, required });
  if (s === undefined) return undefined;
  if (!EMAIL.test(s)) throw new HttpError(400, `${label} is not valid`);
  return s.toLowerCase();
}

function password(v) {
  const s = str(v, 'Password', { min: 8, max: 100 });
  if (!/[a-z]/i.test(s) || !/\d/.test(s)) throw new HttpError(400, 'Password must contain letters and at least one number');
  return s;
}

function stringList(v) {
  if (v === undefined || v === null || v === '') return [];
  const arr = Array.isArray(v) ? v : String(v).split(',');
  return arr.map((s) => String(s).trim().toLowerCase()).filter(Boolean).slice(0, 10);
}

const validateRegister = (b) => ({ name: str(b.name, 'Name', { min: 2, max: 80 }), email: email(b.email), password: password(b.password) });
const validateLogin = (b) => ({ email: email(b.email), password: str(b.password, 'Password', { max: 100 }) });

function validateProduct(b, partial = false) {
  const req = !partial;
  const out = {
    name: str(b.name, 'Name', { max: 120, required: req }),
    sku: str(b.sku, 'SKU', { max: 40, required: false }),
    category: str(b.category, 'Category', { max: 60, required: false }),
    description: str(b.description, 'Description', { max: 1000, required: false }),
    color: str(b.color, 'Color', { max: 30, required: false }),
    size: str(b.size, 'Size', { max: 30, required: false }),
    price: num(b.price, 'Price', { required: req }),
    costPrice: num(b.costPrice, 'Cost price', { required: false }),
    lowStockThreshold: num(b.lowStockThreshold, 'Low stock threshold', { integer: true, required: false }),
    unit: str(b.unit, 'Unit', { max: 20, required: false }),
  };
  if (b.aliases !== undefined) out.aliases = stringList(b.aliases);
  if (!partial && b.stock !== undefined && b.stock !== '') out.stock = num(b.stock, 'Opening stock', { integer: true });
  Object.keys(out).forEach((k) => out[k] === undefined && delete out[k]);
  return out;
}

function validateCustomer(b, partial = false) {
  const out = {
    name: str(b.name, 'Name', { max: 100, required: !partial }),
    phone: str(b.phone, 'Phone', { max: 25, required: false }),
    email: email(b.email, 'Email', false),
    address: str(b.address, 'Address', { max: 300, required: false }),
    notes: str(b.notes, 'Notes', { max: 500, required: false }),
  };
  Object.keys(out).forEach((k) => out[k] === undefined && delete out[k]);
  return out;
}

module.exports = { str, num, email, password, validateRegister, validateLogin, validateProduct, validateCustomer };
