# SalesSync — Setup Guide (Windows CMD)

## 1. Prerequisites
- **Node.js 18 or newer** (https://nodejs.org, LTS). Check: `node -v` and `npm -v`
- **MongoDB 5.0+** — either a free **MongoDB Atlas** cluster (recommended; transactions work out of the box) or a local install
- A modern **Chrome or Edge** for voice commands

## 2. Get MongoDB

### Option A — MongoDB Atlas (recommended)
1. Create a free account at https://www.mongodb.com/atlas and create a free cluster.
2. *Database Access* → add a database user (username + strong password).
3. *Network Access* → add your current IP address.
4. *Connect → Drivers* → copy the connection string and add the database name:
   `mongodb+srv://<user>:<password>@<cluster>.mongodb.net/salessync?retryWrites=true&w=majority`
   (URL-encode special characters in the password.)

### Option B — Local MongoDB
- **Standalone** (simplest): `MONGODB_URI=mongodb://127.0.0.1:27017/salessync`. Works, but there are no transactions; SalesSync uses atomic updates + compensating rollback (the startup log says so).
- **Local replica set** (enables real transactions). In one CMD window (adjust the version folder):
  ```bat
  mkdir C:\data\rs0
  "C:\Program Files\MongoDB\Server\7.0\bin\mongod.exe" --replSet rs0 --dbpath C:\data\rs0 --bind_ip 127.0.0.1
  ```
  In a second window, once only:
  ```bat
  mongosh --eval "rs.initiate()"
  ```
  Then use `MONGODB_URI=mongodb://127.0.0.1:27017/salessync?replicaSet=rs0`.

## 3. Configure the server
```bat
cd SalesSync\server
copy .env.example .env
notepad .env
```
Fill in:
- `MONGODB_URI` — from step 2
- `JWT_SECRET` — generate one and paste it:
  ```bat
  node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
  ```
- `CLIENT_ORIGIN` — leave `http://localhost:5173` for local use
- `GOOGLE_CLIENT_ID` — optional, see step 6

Never commit `.env` and never share the JWT secret.

## 4. Install and create the first admin
```bat
cd SalesSync\server
npm install
npm run create-user -- --name "Admin" --email admin@example.com --role ADMIN
```
You'll be asked for the password (hidden). Min 8 characters, letters + a number.
Public registration only ever creates **STAFF** accounts, so the first admin must be created with this command (it talks to MongoDB directly and needs your `.env`).

## 5. Run (two terminals)
**Terminal 1 — backend**
```bat
cd SalesSync\server
npm run dev
```
Expect: `MongoDB connected (...)` and `SalesSync API listening on http://localhost:5000`. Check http://localhost:5000/api/health.

**Terminal 2 — frontend**
```bat
cd SalesSync\client
copy .env.example .env
npm install
npm run dev
```
Open http://localhost:5173 and log in with the admin you created.

Production build check: `cd SalesSync\client && npm run build`.

## 6. Google OAuth (optional)
1. Go to https://console.cloud.google.com → create/select a project.
2. *APIs & Services → OAuth consent screen*: configure (External, add your email as a test user while testing).
3. *Credentials → Create credentials → OAuth client ID → Web application*.
4. Under **Authorized JavaScript origins** add `http://localhost:5173` (and your production URL later). No redirect URI is needed for the Google button flow used here.
5. Copy the **Client ID** into **both** `server\.env` (`GOOGLE_CLIENT_ID=`) and `client\.env` (`VITE_GOOGLE_CLIENT_ID=`).
6. Restart both servers. A "Continue with Google" button appears on the login page.

Google sign-in creates a **STAFF** user on first login. Promote them from the Admin panel.
This feature is implemented but **unverified until you test it with your own Client ID**.

## 7. Create and test five real users with different roles
After the first admin exists (step 4), run these from `SalesSync\server`. Using the `SALESSYNC_PASSWORD` variable avoids the prompt (the quotes matter in CMD — they prevent a trailing space in the value):
```bat
set "SALESSYNC_PASSWORD=Admin12345"
npm run create-user -- --name "Asha Admin" --email asha.admin@example.com --role ADMIN
set "SALESSYNC_PASSWORD=Owner12345"
npm run create-user -- --name "Omar Owner" --email omar.owner@example.com --role OWNER
npm run create-user -- --name "Olivia Owner" --email olivia.owner@example.com --role OWNER
set "SALESSYNC_PASSWORD=Staff12345"
npm run create-user -- --name "Sam Staff" --email sam.staff@example.com --role STAFF
npm run create-user -- --name "Sara Staff" --email sara.staff@example.com --role STAFF
set SALESSYNC_PASSWORD=
```
These are **examples — choose your own strong passwords** and delete test users before real use. You can also create users from the UI: log in as ADMIN → **Admin panel → Create user**, or use **Register** (always STAFF).

Verify they exist (MongoDB shell): `mongosh "<your MONGODB_URI>" --eval "db.users.find({}, {email:1, role:1})"`

### Role test matrix
| Action | ADMIN | OWNER | STAFF |
|---|---|---|---|
| Open Admin panel / `/api/admin/*` | ✅ | ❌ 403 | ❌ 403 |
| Create / edit / delete products | ✅ | ✅ | ❌ 403 |
| Add / reduce stock (UI, API, voice) | ✅ | ✅ | ❌ |
| Create sales, say "sell 2 …" | ✅ | ✅ | ✅ |
| See all sales | ✅ | ✅ | own only |
| Stock report | ✅ | ✅ | ❌ 403 |
| Customers: create / edit | ✅ | ✅ | ✅ |
| Customers: delete | ✅ | ✅ | ❌ 403 |

Quick API check (CMD):
```bat
curl -X POST http://localhost:5000/api/auth/login -H "Content-Type: application/json" -d "{\"email\":\"sam.staff@example.com\",\"password\":\"Staff12345\"}"
curl http://localhost:5000/api/admin/stats -H "Authorization: Bearer <token from login>"
```
The second call must return `403` for the STAFF token and `200` for the ADMIN token.

## 8. Enter your own business data
The database starts empty. Log in as ADMIN/OWNER → **Products → Add product** (give an opening stock if you like). Then try sales, stock adjustments and voice commands. Add colour/size to create variants (e.g. Shirt / blue / M and Shirt / red / L) and the voice assistant will ask which one you mean.

## 9. Test checklist (nothing below has been run for you)
1. Server starts; log shows transactions ENABLED (replica set/Atlas) or the fallback message (standalone).
2. Register a user → lands in dashboard as STAFF. Log out / log in again.
3. As OWNER: add 2 shirt variants and a smartphone, each with stock.
4. New sale for more than available stock → rejected with *Insufficient stock*; stock unchanged.
5. Valid sale → stock reduced, appears in Sales history, Inventory ledger (type SALE), Reports.
6. Reduce stock until ≤ threshold → alert appears; add stock → alert disappears.
7. Voice: "Add 10 shirts to stock" → asks which shirt → answer "blue" → stock +10.
8. Voice: "Sell 2 smartphones", "how many are left?", "show today's sales", "add 5 more".
9. Voice: unknown product ("add 3 laptops") → asks you to add the product first; nothing is created.
10. Voice as STAFF: "add 5 chargers" → refused; "sell 1 charger" → works.
11. Concurrency (optional): two browser tabs sell the last unit at the same moment; exactly one must succeed.
12. Image upload on a product; delete a product (it disappears from lists, old sales stay intact).
13. Recently opened page lists items you opened.
14. Resize the browser to phone width; sidebar becomes a slide-out menu.
15. Google login (only after step 6).

## 10. Troubleshooting
- **`Configuration error: JWT_SECRET...`** — `.env` missing or secret shorter than 32 characters.
- **`Failed to connect to MongoDB`** — wrong URI, Atlas IP not allow-listed, or local `mongod` not running.
- **Reports return an error about `$dateTrunc`** — MongoDB is older than 5.0.
- **CORS error in browser** — `CLIENT_ORIGIN` must exactly match the browser URL (e.g. `http://localhost:5173`).
- **Mic doesn't work** — use Chrome/Edge, allow the microphone prompt, and keep internet on (Chrome's recognizer is cloud-based). Typing commands in the panel always works.
- **Port in use** — change `PORT` in `server\.env` and `VITE_API_BASE_URL` in `client\.env`.
