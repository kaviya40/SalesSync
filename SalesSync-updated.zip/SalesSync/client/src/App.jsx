import { useEffect } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { loadMe } from './redux/authSlice';
import { TOKEN_KEY } from './services/api';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import Layout from './components/Layout.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Products from './pages/Products.jsx';
import Inventory from './pages/Inventory.jsx';
import Sales from './pages/Sales.jsx';
import NewSale from './pages/NewSale.jsx';
import Customers from './pages/Customers.jsx';
import Reports from './pages/Reports.jsx';
import Recent from './pages/Recent.jsx';
import Notifications from './pages/Notifications.jsx';
import Admin from './pages/Admin.jsx';
import NotFound from './pages/NotFound.jsx';

export default function App() {
  const dispatch = useDispatch();
  const { user, initializing } = useSelector((s) => s.auth);

  useEffect(() => {
    if (localStorage.getItem(TOKEN_KEY)) dispatch(loadMe());
  }, [dispatch]);

  if (initializing) return <div className="splash"><div className="spinner-border text-secondary" role="status" /></div>;

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} />
      <Route path="/register" element={user ? <Navigate to="/" replace /> : <Register />} />
      <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
        <Route index element={<Dashboard />} />
        <Route path="products" element={<Products />} />
        <Route path="inventory" element={<Inventory />} />
        <Route path="sales" element={<Sales />} />
        <Route path="sales/new" element={<NewSale />} />
        <Route path="customers" element={<Customers />} />
        <Route path="reports" element={<Reports />} />
        <Route path="recent" element={<Recent />} />
        <Route path="notifications" element={<Notifications />} />
        <Route path="admin" element={<ProtectedRoute roles={['ADMIN']}><Admin /></ProtectedRoute>} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
