import axios from 'axios';

export const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';
const FILE_BASE = API_BASE.replace(/\/api\/?$/, '');
export const TOKEN_KEY = 'salessync_token';

export const assetUrl = (p) => (p ? (p.startsWith('http') ? p : FILE_BASE + p) : null);
export const errorMessage = (err) => err?.response?.data?.message || (err?.code === 'ERR_NETWORK' ? 'Cannot reach the server. Is the backend running?' : err?.message) || 'Something went wrong';

const api = axios.create({ baseURL: API_BASE, timeout: 20000 });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    const isAuthCall = /\/auth\/(login|register|google)/.test(err.config?.url || '');
    if (err.response?.status === 401 && !isAuthCall && localStorage.getItem(TOKEN_KEY)) {
      window.dispatchEvent(new Event('salessync:logout'));
    }
    return Promise.reject(err);
  }
);

export default api;
