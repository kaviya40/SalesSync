import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import useFetch from '../hooks/useFetch';
import { Empty, ErrorBox, Spinner } from '../components/ui.jsx';
import { money, num, periodLabel } from '../utils/format';

function Stat({ label, value, tone }) {
  return (
    <div className="col-6 col-lg">
      <div className={`panel stat ${tone || ''}`}>
        <div className="label">{label}</div>
        <div className="value">{value}</div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const user = useSelector((s) => s.auth.user);
  const version = useSelector((s) => s.ui.dataVersion);
  const { data, loading, error, refetch } = useFetch('/reports/overview', { deps: [version] });

  if (loading && !data) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={refetch} />;
  const trend = (data.trend || []).map((r) => ({ ...r, label: periodLabel(r.periodStart, 'daily') }));
  const nothingYet = data.products === 0;

  return (
    <>
      <div className="page-head">
        <h1>Hello, {user.name.split(' ')[0]}</h1>
        <Link className="btn btn-primary" to="/sales/new">New sale</Link>
      </div>

      {nothingYet && (
        <div className="panel panel-body mb-3">
          <strong>Your store is empty.</strong> Start by <Link to="/products">adding your first product</Link>, then record stock and sales. You can also use the mic button to speak commands once products exist.
        </div>
      )}

      <div className="row g-3 mb-3">
        <Stat label="Revenue today" value={money(data.today.revenue)} />
        <Stat label="Orders today" value={num(data.today.orders)} />
        <Stat label="Products" value={num(data.products)} />
        <Stat label="Low stock" value={num(data.lowStock)} tone={data.lowStock ? 'warn' : ''} />
        <Stat label="Out of stock" value={num(data.outOfStock)} tone={data.outOfStock ? 'bad' : ''} />
      </div>

      <div className="row g-3">
        <div className="col-lg-7">
          <div className="panel">
            <div className="panel-head"><strong>Revenue, last 14 days</strong></div>
            <div className="panel-body chart-box">
              {trend.length === 0 ? <Empty title="No sales yet">Revenue appears here after your first sale.</Empty> : (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trend}>
                    <CartesianGrid stroke="#e7ece9" vertical={false} />
                    <XAxis dataKey="label" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} width={55} />
                    <Tooltip formatter={(v, n) => (n === 'revenue' ? money(v) : v)} />
                    <Line type="monotone" dataKey="revenue" stroke="#1f5f66" strokeWidth={2.5} dot={{ r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>
        </div>
        <div className="col-lg-5">
          <div className="panel">
            <div className="panel-head"><strong>Top sellers, 30 days</strong></div>
            <div className="panel-body chart-box">
              {data.topProducts.length === 0 ? <Empty title="Nothing sold yet">Your best sellers will be ranked here.</Empty> : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.topProducts} layout="vertical" margin={{ left: 10 }}>
                    <CartesianGrid stroke="#e7ece9" horizontal={false} />
                    <XAxis type="number" tick={{ fontSize: 12 }} allowDecimals={false} />
                    <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 12 }} />
                    <Tooltip />
                    <Bar dataKey="unitsSold" name="Units sold" fill="#d8921c" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
