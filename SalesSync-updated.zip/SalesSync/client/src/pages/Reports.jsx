import { useState } from 'react';
import { useSelector } from 'react-redux';
import { Bar, BarChart, CartesianGrid, Legend, Line, ComposedChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import useFetch from '../hooks/useFetch';
import { Empty, ErrorBox, Spinner } from '../components/ui.jsx';
import { money, num, periodLabel, productLabel, roleCan } from '../utils/format';

export default function Reports() {
  const user = useSelector((s) => s.auth.user);
  const version = useSelector((s) => s.ui.dataVersion);
  const canStock = roleCan(user, 'ADMIN', 'OWNER');
  const [period, setPeriod] = useState('daily');
  const [days, setDays] = useState(30);

  const sales = useFetch('/reports/sales', { params: { period }, deps: [version] });
  const top = useFetch('/reports/top-products', { params: { days }, deps: [version] });
  const stock = useFetch('/reports/stock', { enabled: canStock, deps: [version] });
  const series = (sales.data?.series || []).map((r) => ({ ...r, label: periodLabel(r.periodStart, period) }));
  const t = sales.data?.totals;

  return (
    <>
      <div className="page-head">
        <h1>Reports</h1>
        <div className="btn-group" role="group" aria-label="Report period">
          {['daily', 'weekly', 'monthly'].map((p) => <button key={p} className={`btn ${period === p ? 'btn-primary' : 'btn-outline-primary'}`} onClick={() => setPeriod(p)}>{p[0].toUpperCase() + p.slice(1)}</button>)}
        </div>
      </div>

      <ErrorBox message={sales.error} onRetry={sales.refetch} />
      <div className="row g-3 mb-3">
        {[['Revenue', t ? money(t.revenue) : '—'], ['Orders', t ? num(t.orders) : '—'], ['Units sold', t ? num(t.units) : '—']].map(([l, v]) => (
          <div className="col-4" key={l}><div className="panel stat"><div className="label">{l}</div><div className="value">{v}</div></div></div>
        ))}
      </div>

      <div className="panel mb-3">
        <div className="panel-head"><strong>{period[0].toUpperCase() + period.slice(1)} sales</strong></div>
        <div className="panel-body chart-box">
          {sales.loading && !sales.data ? <Spinner /> : series.length === 0 ? <Empty title="No sales in this period">Record a sale to see this chart.</Empty> : (
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={series}>
                <CartesianGrid stroke="#e7ece9" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 12 }} />
                <YAxis yAxisId="l" tick={{ fontSize: 12 }} width={60} />
                <YAxis yAxisId="r" orientation="right" tick={{ fontSize: 12 }} allowDecimals={false} width={35} />
                <Tooltip formatter={(v, n) => (n === 'Revenue' ? money(v) : v)} />
                <Legend />
                <Bar yAxisId="l" dataKey="revenue" name="Revenue" fill="#1f5f66" radius={[4, 4, 0, 0]} />
                <Line yAxisId="r" type="monotone" dataKey="orders" name="Orders" stroke="#d8921c" strokeWidth={2.5} />
              </ComposedChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      <div className="row g-3">
        <div className="col-lg-6">
          <div className="panel">
            <div className="panel-head"><strong>Top-selling products</strong>
              <select className="form-select form-select-sm" style={{ width: 'auto' }} value={days} onChange={(e) => setDays(Number(e.target.value))} aria-label="Range"><option value={7}>7 days</option><option value={30}>30 days</option><option value={90}>90 days</option><option value={365}>1 year</option></select>
            </div>
            {top.loading && !top.data ? <Spinner /> : top.data?.items.length === 0 ? <Empty title="Nothing sold in this range" /> : (
              <div className="table-responsive"><table className="table mb-0"><thead><tr><th>Product</th><th className="text-end">Units</th><th className="text-end">Revenue</th></tr></thead>
                <tbody>{top.data?.items.map((p) => <tr key={p.productId}><td>{p.name}</td><td className="text-end">{p.unitsSold}</td><td className="text-end">{money(p.revenue)}</td></tr>)}</tbody></table></div>
            )}
          </div>
        </div>
        <div className="col-lg-6">
          <div className="panel">
            <div className="panel-head"><strong>Stock report</strong></div>
            {!canStock ? <Empty title="Owners and admins only">Stock reports are limited to owners and admins.</Empty> : stock.loading && !stock.data ? <Spinner /> : stock.data && (
              <div className="panel-body">
                <ErrorBox message={stock.error} />
                <div className="row text-center g-2 mb-3">
                  <div className="col-4"><div className="fs-4 fw-bold">{num(stock.data.summary.products)}</div><small className="text-muted">Products</small></div>
                  <div className="col-4"><div className="fs-4 fw-bold">{num(stock.data.summary.units)}</div><small className="text-muted">Units in stock</small></div>
                  <div className="col-4"><div className="fs-4 fw-bold">{money(stock.data.summary.retailValue)}</div><small className="text-muted">Retail value</small></div>
                </div>
                <h6>Low stock ({stock.data.lowStock.length})</h6>
                {stock.data.lowStock.length === 0 ? <p className="text-muted small">None.</p> : <ul className="small">{stock.data.lowStock.map((p) => <li key={p._id}>{productLabel(p)} — {p.stock} left</li>)}</ul>}
                <h6>Out of stock ({stock.data.outOfStock.length})</h6>
                {stock.data.outOfStock.length === 0 ? <p className="text-muted small mb-0">None.</p> : <ul className="small mb-0">{stock.data.outOfStock.map((p) => <li key={p._id}>{productLabel(p)}</li>)}</ul>}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
