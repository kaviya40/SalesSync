import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { clearAuthError, register } from '../redux/authSlice';
import { AuthShell } from './Login.jsx';

export default function Register() {
  const dispatch = useDispatch();
  const { loading, error } = useSelector((s) => s.auth);
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const set = (k) => (e) => { if (error) dispatch(clearAuthError()); setForm({ ...form, [k]: e.target.value }); };

  return (
    <AuthShell title="Create your account">
      {error && <div className="alert alert-danger py-2" role="alert">{error}</div>}
      <form onSubmit={(e) => { e.preventDefault(); dispatch(register(form)); }}>
        <label className="form-label" htmlFor="name">Name</label>
        <input id="name" className="form-control mb-3" value={form.name} onChange={set('name')} autoComplete="name" required minLength={2} />
        <label className="form-label" htmlFor="email">Email</label>
        <input id="email" type="email" className="form-control mb-3" value={form.email} onChange={set('email')} autoComplete="email" required />
        <label className="form-label" htmlFor="password">Password</label>
        <input id="password" type="password" className="form-control" value={form.password} onChange={set('password')} autoComplete="new-password" required minLength={8} />
        <div className="form-text mb-3">At least 8 characters, with letters and a number. New accounts start as STAFF; an admin can change roles.</div>
        <button className="btn btn-primary w-100" disabled={loading}>{loading ? 'Creating…' : 'Create account'}</button>
      </form>
      <p className="mt-4 mb-0 text-center">Already registered? <Link to="/login">Log in</Link></p>
    </AuthShell>
  );
}
