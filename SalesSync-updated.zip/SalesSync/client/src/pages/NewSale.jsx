import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import api, { errorMessage } from '../services/api';
import useFetch from '../hooks/useFetch';
import { bumpData } from '../redux/uiSlice';
import { fetchNotifications } from '../redux/notificationsSlice';
import { ErrorBox, StockPill } from '../components/ui.jsx';
import { money, productLabel } from '../utils/format';

export default function NewSale() {
  const dispatch = useDispatch();
  const version = useSelector((s) => s.ui.dataVersion);
  const [q, setQ] = useState('');
  const [debounced, setDebounced] = useState('');
  const [cart, setCart] = useState([]);
  const [customerId, setCustomerId] = useState('');
  const [discount, setDiscount] = useState('');
  const [payment, setPayment] = useState('CASH');
  const [note, setNote] = useState('');
  const [error, setError] = useState(null);
  const [done, setDone] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => { const t = setTimeout(() => setDebounced(q), 300); return () => clearTimeout(t); }, [q]);
  const results = useFetch('/products', { params: { q: debounced, limit: 8, sort: 'name' }, deps: [version] });
  const customers = useFetch('/customers', { params: { limit: 100 }, deps: [version] });

  const add = (p) => {
    if (p.stock <= 0) return;
    setCart((c) => {
      const found = c.find((i) => i.product._id === p._id);
      if (found) return c.map((i) => (i.product._id === p._id ? { ...i, quantity: Math.min(i.quantity + 1, p.stock) } : i));
      return [...c, { product: p, quantity: 1 }];
    });
  };
  const setQty = (id, v) => setCart((c) => c.map((i) => (i.product._id === id ? { ...i, quantity: Math.max(1, Math.min(Number(v) || 1, i.product.stock)) } : i)));
  const remove = (id) => setCart((c) => c.filter((i) => i.product._id !== id));

  const subtotal = useMemo(() => cart.reduce((s, i) => s + i.product.price * i.quantity, 0), [cart]);
  const disc = Number(discount) || 0;
  const total = Math.max(0, subtotal - disc);

  const submit = async () => {
    setSaving(true);
    setError(null);
    try {
      const { data } = await api.post('/sales', { items: cart.map((i) => ({ productId: i.product._id, quantity: i.quantity })), customerId: customerId || undefined, discount: disc, paymentMethod: payment, note: note || undefined });
      setDone(data.sale);
      setCart([]); setDiscount(''); setNote(''); setCustomerId('');
      dispatch(bumpData());
      dispatch(fetchNotifications());
    } catch (err) {
      setError(errorMessage(err));
      dispatch(bumpData()); // stock may have changed elsewhere; refresh the list
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <div className="page-head"><h1>New sale</h1><Link to="/sales" className="btn btn-outline-secondary">Sales history</Link></div>
      {done && (
        <div className="alert alert-success d-flex justify-content-between flex-wrap gap-2">
          <span>Sale <strong>{done.invoiceNumber}</strong> saved for {money(done.total)}. Stock has been updated.</span>
          <button className="btn btn-sm btn-outline-success" onClick={() => setDone(null)}>Dismiss</button>
        </div>
      )}
      <div className="row g-3">
        <div className="col-lg-6">
          <div className="panel">
            <div className="panel-head"><strong>Find products</strong></div>
            <div className="panel-body">
              <input className="form-control mb-3" placeholder="Search by name, SKU or colour" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search products" />
              <ErrorBox message={results.error} onRetry={results.refetch} />
              {results.data?.items.length === 0 && <p className="text-muted mb-0">{debounced ? 'No matching products.' : 'No products yet. Add products first.'}</p>}
              <div className="list-group">
                {results.data?.items.map((p) => (
                  <button key={p._id} className="list-group-item list-group-item-action d-flex justify-content-between align-items-center" disabled={p.stock <= 0} onClick={() => add(p)}>
                    <span><strong>{productLabel(p)}</strong><br /><small className="text-muted">{money(p.price)}</small></span>
                    <StockPill product={p} />
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-6">
          <div className="panel">
            <div className="panel-head"><strong>Cart</strong></div>
            <div className="panel-body">
              {cart.length === 0 ? <p className="text-muted">Choose products from the left to build the sale.</p> : (
                <div className="table-responsive">
                  <table className="table table-sm line-items align-middle">
                    <thead><tr><th>Item</th><th style={{ width: 90 }}>Qty</th><th className="text-end">Amount</th><th /></tr></thead>
                    <tbody>{cart.map((i) => (
                      <tr key={i.product._id}><td>{productLabel(i.product)}<div className="small text-muted">{money(i.product.price)} · max {i.product.stock}</div></td>
                        <td><input type="number" min="1" max={i.product.stock} className="form-control form-control-sm" value={i.quantity} onChange={(e) => setQty(i.product._id, e.target.value)} /></td>
                        <td className="text-end">{money(i.product.price * i.quantity)}</td>
                        <td><button className="btn btn-sm btn-link text-danger" onClick={() => remove(i.product._id)}>Remove</button></td></tr>
                    ))}</tbody>
                  </table>
                </div>
              )}
              <div className="row g-2 mt-1">
                <div className="col-sm-6"><label className="form-label">Customer (optional)</label>
                  <select className="form-select" value={customerId} onChange={(e) => setCustomerId(e.target.value)}><option value="">Walk-in</option>{customers.data?.items.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}</select></div>
                <div className="col-sm-6"><label className="form-label">Payment</label>
                  <select className="form-select" value={payment} onChange={(e) => setPayment(e.target.value)}><option value="CASH">Cash</option><option value="UPI">UPI</option><option value="CARD">Card</option><option value="OTHER">Other</option></select></div>
                <div className="col-sm-6"><label className="form-label">Discount (₹)</label><input type="number" min="0" className="form-control" value={discount} onChange={(e) => setDiscount(e.target.value)} /></div>
                <div className="col-sm-6"><label className="form-label">Note</label><input className="form-control" value={note} onChange={(e) => setNote(e.target.value)} maxLength={300} /></div>
              </div>
              <hr />
              <div className="d-flex justify-content-between"><span>Subtotal</span><span>{money(subtotal)}</span></div>
              <div className="d-flex justify-content-between fs-5 fw-bold"><span>Total</span><span>{money(total)}</span></div>
              <div className="form-text mb-3">The server recalculates prices and totals when the sale is saved.</div>
              <ErrorBox message={error} />
              <button className="btn btn-primary w-100" disabled={saving || cart.length === 0 || disc > subtotal} onClick={submit}>{saving ? 'Saving sale…' : 'Complete sale'}</button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
