import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { clearAuthError, login } from '../redux/authSlice';

export function AuthShell({ title, children }) {
  return (
    <div className="auth-wrap">
      <div className="auth-side">
        <div className="brand p-0 mb-4" style={{ fontSize: '1.6rem' }}>Sales<span>Sync</span></div>
        <h1>Sell and restock by simply saying it.</h1>
      </div>
      <div className="auth-form">
        <div className="box">
          <h2 className="mb-3">{title}</h2>
          {children}
        </div>
      </div>
    </div>
  );
}

export default function Login() {
  const dispatch = useDispatch();
  const { loading, error } = useSelector((s) => s.auth);
  const [form, setForm] = useState({ email: '', password: '' });
  const set = (k) => (e) => { if (error) dispatch(clearAuthError()); setForm({ ...form, [k]: e.target.value }); };

  return (
    <AuthShell title="Log in">
      {error && <div className="alert alert-danger py-2" role="alert">{error}</div>}
      <form onSubmit={(e) => { e.preventDefault(); dispatch(login(form)); }}>
        <label className="form-label" htmlFor="email">Email</label>
        <input id="email" type="email" className="form-control mb-3" value={form.email} onChange={set('email')} autoComplete="email" required />
        <label className="form-label" htmlFor="password">Password</label>
        <input id="password" type="password" className="form-control mb-3" value={form.password} onChange={set('password')} autoComplete="current-password" required />
        <button className="btn btn-primary w-100" disabled={loading}>{loading ? 'Logging in…' : 'Log in'}</button>
      </form>
      <p className="mt-4 mb-0 text-center">New here? <Link to="/register">Create an account</Link></p>
    </AuthShell>
  );
}
