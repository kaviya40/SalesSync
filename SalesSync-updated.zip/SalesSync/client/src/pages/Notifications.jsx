import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { fetchNotifications, markAllRead, markRead } from '../redux/notificationsSlice';
import { Empty } from '../components/ui.jsx';
import { dateTime } from '../utils/format';

export default function Notifications() {
  const dispatch = useDispatch();
  const { items, unread } = useSelector((s) => s.notifications);
  const version = useSelector((s) => s.ui.dataVersion);
  useEffect(() => { dispatch(fetchNotifications()); }, [dispatch, version]);

  return (
    <>
      <div className="page-head">
        <h1>Stock alerts</h1>
        <button className="btn btn-outline-secondary" disabled={unread === 0} onClick={() => dispatch(markAllRead())}>Mark all as read</button>
      </div>
      <div className="panel">
        {items.length === 0 ? <Empty title="No active alerts">You'll be notified here when a product runs low or out of stock.</Empty> : (
          <ul className="list-group list-group-flush">
            {items.map((n) => (
              <li key={n._id} className="list-group-item d-flex justify-content-between align-items-center gap-2" style={n.read ? undefined : { background: '#fff8ea' }}>
                <div>
                  <span className={`pill ${n.type === 'OUT_OF_STOCK' ? 'out' : 'low'} me-2`}>{n.type === 'OUT_OF_STOCK' ? 'Out of stock' : 'Low stock'}</span>
                  {n.message} <div className="small text-muted">{dateTime(n.createdAt)} · {n.product && <Link to={`/products?view=${n.product._id}`}>View product</Link>}</div>
                </div>
                {!n.read && <button className="btn btn-sm btn-light" onClick={() => dispatch(markRead(n._id))}>Mark read</button>}
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
}
