import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import api, { assetUrl, errorMessage } from '../services/api';
import useFetch from '../hooks/useFetch';
import { fetchProducts, resetFilters, setFilters } from '../redux/productsSlice';
import { bumpData } from '../redux/uiSlice';
import { fetchNotifications } from '../redux/notificationsSlice';
import { Empty, ErrorBox, Modal, Pager, Spinner, StockPill, Thumb } from '../components/ui.jsx';
import { dateTime, money, productLabel, roleCan } from '../utils/format';

const EMPTY = { name: '', sku: '', category: '', color: '', size: '', price: '', costPrice: '', stock: '', lowStockThreshold: 5, unit: 'pcs', aliases: '', description: '' };

function ProductForm({ product, categories, onClose, onSaved }) {
  const editing = Boolean(product);
  const [form, setForm] = useState(product ? { ...EMPTY, ...product, aliases: (product.aliases || []).join(', '), stock: '' } : EMPTY);
  const [file, setFile] = useState(null);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const fd = new FormData();
    ['name', 'sku', 'category', 'color', 'size', 'price', 'costPrice', 'lowStockThreshold', 'unit', 'aliases', 'description'].forEach((k) => fd.append(k, form[k] ?? ''));
    if (!editing && form.stock !== '') fd.append('stock', form.stock);
    if (file) fd.append('image', file);
    try {
      if (editing) await api.put(`/products/${product._id}`, fd);
      else await api.post('/products', fd);
      onSaved();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal title={editing ? 'Edit product' : 'Add product'} onClose={onClose}>
      <form onSubmit={submit}>
        <ErrorBox message={error} />
        <div className="row g-3">
          <div className="col-md-8"><label className="form-label">Name *</label><input className="form-control" value={form.name} onChange={set('name')} required maxLength={120} /></div>
          <div className="col-md-4"><label className="form-label">SKU</label><input className="form-control" value={form.sku} onChange={set('sku')} placeholder="Auto if empty" maxLength={40} /></div>
          <div className="col-md-4"><label className="form-label">Category</label><input className="form-control" list="cat-list" value={form.category} onChange={set('category')} /><datalist id="cat-list">{categories.map((c) => <option key={c} value={c} />)}</datalist></div>
          <div className="col-md-4"><label className="form-label">Colour</label><input className="form-control" value={form.color} onChange={set('color')} /></div>
          <div className="col-md-4"><label className="form-label">Size</label><input className="form-control" value={form.size} onChange={set('size')} /></div>
          <div className="col-md-4"><label className="form-label">Selling price (₹) *</label><input type="number" min="0" step="0.01" className="form-control" value={form.price} onChange={set('price')} required /></div>
          <div className="col-md-4"><label className="form-label">Cost price (₹)</label><input type="number" min="0" step="0.01" className="form-control" value={form.costPrice} onChange={set('costPrice')} /></div>
          <div className="col-md-4"><label className="form-label">Low-stock alert at</label><input type="number" min="0" className="form-control" value={form.lowStockThreshold} onChange={set('lowStockThreshold')} /></div>
          {!editing && <div className="col-md-4"><label className="form-label">Opening stock</label><input type="number" min="0" className="form-control" value={form.stock} onChange={set('stock')} placeholder="0" /></div>}
          <div className="col-md-4"><label className="form-label">Unit</label><input className="form-control" value={form.unit} onChange={set('unit')} /></div>
          <div className="col-12"><label className="form-label">Spoken names (optional)</label><input className="form-control" value={form.aliases} onChange={set('aliases')} placeholder="e.g. sattai, shirts — comma separated, used by voice commands" /></div>
          <div className="col-12"><label className="form-label">Description</label><textarea className="form-control" rows={2} value={form.description} onChange={set('description')} maxLength={1000} /></div>
          <div className="col-12"><label className="form-label">Image (JPG/PNG/WEBP, max 2 MB)</label><input type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="form-control" onChange={(e) => setFile(e.target.files[0] || null)} /></div>
        </div>
        <div className="d-flex justify-content-end gap-2 mt-4">
          <button type="button" className="btn btn-light" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : editing ? 'Save changes' : 'Add product'}</button>
        </div>
      </form>
    </Modal>
  );
}

function ProductDetail({ id, onClose }) {
  const { data, loading, error } = useFetch(`/products/${id}`);
  return (
    <Modal title="Product details" onClose={onClose} wide>
      {loading && <Spinner />}
      <ErrorBox message={error} />
      {data && (
        <>
          <div className="d-flex gap-3 mb-3">
            <Thumb src={assetUrl(data.product.image)} name={data.product.name} />
            <div>
              <h5 className="mb-0">{productLabel(data.product)}</h5>
              <div className="text-muted">{data.product.sku} · {data.product.category} · {money(data.product.price)}</div>
              <StockPill product={data.product} />
            </div>
          </div>
          {data.product.description && <p>{data.product.description}</p>}
          <h6>Recent stock movements</h6>
          {data.history.length === 0 ? <p className="text-muted">No movements yet.</p> : (
            <div className="table-responsive"><table className="table table-sm mb-0"><thead><tr><th>When</th><th>Type</th><th>Change</th><th>Stock after</th><th>By</th></tr></thead>
              <tbody>{data.history.map((h) => <tr key={h._id}><td>{dateTime(h.createdAt)}</td><td>{h.type}</td><td>{h.quantityChange > 0 ? '+' : ''}{h.quantityChange}</td><td>{h.stockAfter}</td><td>{h.createdBy?.name || '—'}{h.source === 'voice' ? ' 🎙' : ''}</td></tr>)}</tbody></table></div>
          )}
        </>
      )}
    </Modal>
  );
}

export default function Products() {
  const dispatch = useDispatch();
  const [params, setParams] = useSearchParams();
  const user = useSelector((s) => s.auth.user);
  const version = useSelector((s) => s.ui.dataVersion);
  const { items, total, pages, loading, error, filters } = useSelector((s) => s.products);
  const { data: cats } = useFetch('/products/categories', { deps: [version] });
  const [editing, setEditing] = useState(null); // null | {} (new) | product
  const [viewId, setViewId] = useState(params.get('view'));
  const [reload, setReload] = useState(0);
  const [search, setSearch] = useState(filters.q);
  const canManage = roleCan(user, 'ADMIN', 'OWNER');

  useEffect(() => { dispatch(fetchProducts(filters)); }, [dispatch, filters, version, reload]);
  useEffect(() => { const t = setTimeout(() => search !== filters.q && dispatch(setFilters({ q: search })), 350); return () => clearTimeout(t); }, [search, filters.q, dispatch]);

  const closeView = () => { setViewId(null); if (params.get('view')) setParams({}); };
  const saved = () => { setEditing(null); setReload((n) => n + 1); dispatch(bumpData()); dispatch(fetchNotifications()); };
  const remove = async (p) => {
    if (!window.confirm(`Delete ${productLabel(p)}? Past sales keep their records.`)) return;
    try { await api.delete(`/products/${p._id}`); saved(); } catch (e) { window.alert(errorMessage(e)); }
  };

  return (
    <>
      <div className="page-head">
        <h1>Products</h1>
        {canManage && <button className="btn btn-primary" onClick={() => setEditing({})}>Add product</button>}
      </div>

      <div className="panel panel-body mb-3">
        <div className="search-row">
          <input className="form-control" placeholder="Search name, SKU, colour…" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search products" />
          <select className="form-select" value={filters.category} onChange={(e) => dispatch(setFilters({ category: e.target.value }))} aria-label="Category">
            <option value="">All categories</option>{(cats?.items || []).map((c) => <option key={c}>{c}</option>)}
          </select>
          <select className="form-select" value={filters.stockStatus} onChange={(e) => dispatch(setFilters({ stockStatus: e.target.value }))} aria-label="Stock status">
            <option value="">Any stock level</option><option value="in">In stock</option><option value="low">Low stock</option><option value="out">Out of stock</option>
          </select>
          <select className="form-select" value={`${filters.sort}:${filters.order}`} onChange={(e) => { const [sort, order] = e.target.value.split(':'); dispatch(setFilters({ sort, order })); }} aria-label="Sort">
            <option value="name:asc">Name A–Z</option><option value="price:asc">Price low–high</option><option value="price:desc">Price high–low</option><option value="stock:asc">Stock low–high</option><option value="createdAt:desc">Newest</option>
          </select>
          <button className="btn btn-outline-secondary" onClick={() => { setSearch(''); dispatch(resetFilters()); }}>Clear</button>
        </div>
      </div>

      <ErrorBox message={error} onRetry={() => setReload((n) => n + 1)} />
      <div className="panel">
        {loading && items.length === 0 ? <Spinner /> : items.length === 0 ? (
          <Empty title={total === 0 && !filters.q && !filters.category && !filters.stockStatus ? 'No products yet' : 'No products match these filters'}>
            {canManage ? 'Add your first product to start tracking stock.' : 'Ask an owner or admin to add products.'}
          </Empty>
        ) : (
          <div className="table-responsive">
            <table className="table mb-0">
              <thead><tr><th>Product</th><th>SKU</th><th>Category</th><th className="text-end">Price</th><th>Stock</th><th /></tr></thead>
              <tbody>
                {items.map((p) => (
                  <tr key={p._id}>
                    <td><div className="d-flex align-items-center gap-2"><Thumb src={assetUrl(p.image)} name={p.name} /><div><button className="btn btn-link p-0 fw-semibold text-start" onClick={() => setViewId(p._id)}>{p.name}</button><div className="small text-muted">{[p.color, p.size].filter(Boolean).join(' · ')}</div></div></div></td>
                    <td>{p.sku}</td><td>{p.category}</td><td className="text-end">{money(p.price)}</td><td><StockPill product={p} /></td>
                    <td className="text-end text-nowrap">{canManage && <><button className="btn btn-sm btn-outline-primary me-1" onClick={() => setEditing(p)}>Edit</button><button className="btn btn-sm btn-outline-danger" onClick={() => remove(p)}>Delete</button></>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <Pager page={filters.page} pages={pages} onChange={(page) => dispatch(setFilters({ page }))} />
      </div>

      {editing && <ProductForm product={editing._id ? editing : null} categories={cats?.items || []} onClose={() => setEditing(null)} onSaved={saved} />}
      {viewId && <ProductDetail id={viewId} onClose={closeView} />}
    </>
  );
}
