import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import api, { errorMessage } from '../services/api';
import useFetch from '../hooks/useFetch';
import { bumpData } from '../redux/uiSlice';
import { fetchNotifications } from '../redux/notificationsSlice';
import { Empty, ErrorBox, Pager, Spinner } from '../components/ui.jsx';
import { dateTime, productLabel, roleCan } from '../utils/format';

export default function Inventory() {
  const dispatch = useDispatch();
  const user = useSelector((s) => s.auth.user);
  const version = useSelector((s) => s.ui.dataVersion);
  const canManage = roleCan(user, 'ADMIN', 'OWNER');
  const [page, setPage] = useState(1);
  const [type, setType] = useState('');
  const [form, setForm] = useState({ productId: '', type: 'ADD', quantity: '', reason: '' });
  const [msg, setMsg] = useState(null);
  const [saving, setSaving] = useState(false);

  const products = useFetch('/products', { params: { limit: 100, sort: 'name' }, enabled: canManage, deps: [version] });
  const tx = useFetch('/inventory/transactions', { params: { page, limit: 15, type }, deps: [version] });

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setMsg(null);
    try {
      const { data } = await api.post('/inventory/adjust', { ...form, quantity: Number(form.quantity) });
      setMsg({ ok: true, text: `${productLabel(data.product)} now has ${data.product.stock} in stock.` });
      setForm({ ...form, quantity: '', reason: '' });
      dispatch(bumpData());
      dispatch(fetchNotifications());
    } catch (err) {
      setMsg({ ok: false, text: errorMessage(err) });
    } finally {
      setSaving(false);
    }
  };

  const list = products.data?.items || [];
  return (
    <>
      <div className="page-head"><h1>Inventory</h1></div>
      <div className="row g-3">
        {canManage && (
          <div className="col-lg-4">
            <form className="panel panel-body" onSubmit={submit}>
              <h5 className="mb-3">Adjust stock</h5>
              {msg && <div className={`alert py-2 alert-${msg.ok ? 'success' : 'danger'}`}>{msg.text}</div>}
              <label className="form-label">Product</label>
              <select className="form-select mb-3" value={form.productId} onChange={(e) => setForm({ ...form, productId: e.target.value })} required>
                <option value="">Choose a product…</option>
                {list.map((p) => <option key={p._id} value={p._id}>{productLabel(p)} ({p.stock})</option>)}
              </select>
              {!products.loading && list.length === 0 && <div className="form-text mb-3">No products yet. Add one on the Products page first.</div>}
              <div className="btn-group w-100 mb-3" role="group" aria-label="Adjustment type">
                {['ADD', 'REDUCE'].map((t) => <button type="button" key={t} className={`btn ${form.type === t ? 'btn-primary' : 'btn-outline-primary'}`} onClick={() => setForm({ ...form, type: t })}>{t === 'ADD' ? 'Add stock' : 'Reduce stock'}</button>)}
              </div>
              <label className="form-label">Quantity</label>
              <input type="number" min="1" step="1" className="form-control mb-3" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} required />
              <label className="form-label">Reason</label>
              <input className="form-control mb-3" value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} placeholder="Supplier delivery, damaged, recount…" maxLength={200} />
              <button className="btn btn-primary w-100" disabled={saving}>{saving ? 'Saving…' : 'Save adjustment'}</button>
            </form>
          </div>
        )}
        <div className={canManage ? 'col-lg-8' : 'col-12'}>
          <div className="panel">
            <div className="panel-head">
              <strong>Stock movements</strong>
              <select className="form-select form-select-sm" style={{ width: 'auto' }} value={type} onChange={(e) => { setType(e.target.value); setPage(1); }} aria-label="Filter by type">
                <option value="">All types</option><option value="ADD">Additions</option><option value="REDUCE">Reductions</option><option value="SALE">Sales</option>
              </select>
            </div>
            <ErrorBox message={tx.error} onRetry={tx.refetch} />
            {tx.loading && !tx.data ? <Spinner /> : tx.data?.items.length === 0 ? <Empty title="No movements yet">Stock additions, reductions and sales will be listed here.</Empty> : (
              <div className="table-responsive">
                <table className="table mb-0">
                  <thead><tr><th>When</th><th>Product</th><th>Type</th><th className="text-end">Change</th><th className="text-end">After</th><th>Note</th><th>By</th></tr></thead>
                  <tbody>{tx.data?.items.map((t) => (
                    <tr key={t._id}><td className="text-nowrap">{dateTime(t.createdAt)}</td><td>{t.productName}</td><td>{t.type}</td>
                      <td className={`text-end fw-semibold ${t.quantityChange > 0 ? 'text-success' : 'text-danger'}`}>{t.quantityChange > 0 ? '+' : ''}{t.quantityChange}</td>
                      <td className="text-end">{t.stockAfter}</td><td>{t.reason || '—'}</td><td>{t.createdBy?.name || '—'}{t.source === 'voice' ? ' 🎙' : ''}</td></tr>
                  ))}</tbody>
                </table>
              </div>
            )}
            <Pager page={tx.data?.page || 1} pages={tx.data?.pages} onChange={setPage} />
          </div>
        </div>
      </div>
    </>
  );
}
