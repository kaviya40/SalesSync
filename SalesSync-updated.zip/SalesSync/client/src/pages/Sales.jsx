import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useSelector } from 'react-redux';
import useFetch from '../hooks/useFetch';
import { Empty, ErrorBox, Modal, Pager, Spinner } from '../components/ui.jsx';
import { dateTime, money } from '../utils/format';

function SaleDetail({ id, onClose }) {
  const { data, loading, error } = useFetch(`/sales/${id}`);
  const s = data?.sale;
  return (
    <Modal title={s ? s.invoiceNumber : 'Sale'} onClose={onClose} wide>
      {loading && <Spinner />}
      <ErrorBox message={error} />
      {s && (
        <>
          <p className="text-muted">{dateTime(s.createdAt)} · by {s.createdBy?.name} · {s.paymentMethod}{s.customerName ? ` · ${s.customerName}` : ''}{s.source === 'voice' ? ' · 🎙 voice' : ''}</p>
          <div className="table-responsive"><table className="table table-sm"><thead><tr><th>Item</th><th className="text-end">Qty</th><th className="text-end">Price</th><th className="text-end">Amount</th></tr></thead>
            <tbody>{s.items.map((i) => <tr key={i.product}><td>{i.name}</td><td className="text-end">{i.quantity}</td><td className="text-end">{money(i.unitPrice)}</td><td className="text-end">{money(i.lineTotal)}</td></tr>)}</tbody></table></div>
          <div className="text-end"><div>Subtotal {money(s.subtotal)}</div>{s.discount > 0 && <div>Discount −{money(s.discount)}</div>}<div className="fs-5 fw-bold">Total {money(s.total)}</div></div>
          {s.note && <p className="mt-2 mb-0">Note: {s.note}</p>}
        </>
      )}
    </Modal>
  );
}

export default function Sales() {
  const [params, setParams] = useSearchParams();
  const version = useSelector((s) => s.ui.dataVersion);
  const [page, setPage] = useState(1);
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [viewId, setViewId] = useState(params.get('view'));
  const { data, loading, error, refetch } = useFetch('/sales', { params: { page, limit: 15, from, to }, deps: [version] });
  const closeView = () => { setViewId(null); if (params.get('view')) setParams({}); };

  return (
    <>
      <div className="page-head"><h1>Sales history</h1><Link to="/sales/new" className="btn btn-primary">New sale</Link></div>
      <div className="panel panel-body mb-3">
        <div className="search-row">
          <div><label className="form-label small mb-1">From</label><input type="date" className="form-control" value={from} onChange={(e) => { setFrom(e.target.value); setPage(1); }} /></div>
          <div><label className="form-label small mb-1">To</label><input type="date" className="form-control" value={to} onChange={(e) => { setTo(e.target.value); setPage(1); }} /></div>
          <div className="d-flex align-items-end"><button className="btn btn-outline-secondary" onClick={() => { setFrom(''); setTo(''); setPage(1); }}>Clear dates</button></div>
        </div>
      </div>
      <ErrorBox message={error} onRetry={refetch} />
      <div className="panel">
        {loading && !data ? <Spinner /> : data?.items.length === 0 ? <Empty title="No sales found">Completed sales will appear here.</Empty> : (
          <div className="table-responsive">
            <table className="table mb-0">
              <thead><tr><th>Invoice</th><th>Date</th><th>Items</th><th>Customer</th><th>Payment</th><th className="text-end">Total</th><th>By</th></tr></thead>
              <tbody>{data?.items.map((s) => (
                <tr key={s._id}><td><button className="btn btn-link p-0" onClick={() => setViewId(s._id)}>{s.invoiceNumber}</button>{s.source === 'voice' ? ' 🎙' : ''}</td><td className="text-nowrap">{dateTime(s.createdAt)}</td>
                  <td>{s.items.reduce((n, i) => n + i.quantity, 0)}</td><td>{s.customerName || 'Walk-in'}</td><td>{s.paymentMethod}</td><td className="text-end fw-semibold">{money(s.total)}</td><td>{s.createdBy?.name}</td></tr>
              ))}</tbody>
            </table>
          </div>
        )}
        <Pager page={data?.page || 1} pages={data?.pages} onChange={setPage} />
      </div>
      {viewId && <SaleDetail id={viewId} onClose={closeView} />}
    </>
  );
}
