import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import useFetch from '../hooks/useFetch';
import { Empty, ErrorBox, Spinner } from '../components/ui.jsx';
import { dateTime } from '../utils/format';

const TABS = [['', 'All'], ['product', 'Products'], ['sale', 'Sales'], ['customer', 'Customers'], ['report', 'Reports']];

export default function Recent() {
  const navigate = useNavigate();
  const version = useSelector((s) => s.ui.dataVersion);
  const [type, setType] = useState('');
  const { data, loading, error, refetch } = useFetch('/recent', { params: { type, limit: 30 }, deps: [version] });

  const open = (r) => {
    if (r.entityType === 'product') navigate(`/products?view=${r.entityId}`);
    else if (r.entityType === 'sale') navigate(`/sales?view=${r.entityId}`);
    else if (r.entityType === 'customer') navigate(`/customers?view=${r.entityId}`);
    else navigate('/reports');
  };

  return (
    <>
      <div className="page-head"><h1>Recently opened</h1></div>
      <ul className="nav nav-pills mb-3 gap-1">{TABS.map(([k, label]) => <li className="nav-item" key={k || 'all'}><button className={`nav-link ${type === k ? 'active' : ''}`} style={type === k ? { background: '#1f5f66' } : { color: '#1f5f66' }} onClick={() => setType(k)}>{label}</button></li>)}</ul>
      <ErrorBox message={error} onRetry={refetch} />
      <div className="panel">
        {loading && !data ? <Spinner /> : data?.items.length === 0 ? <Empty title="Nothing here yet">Products, sales, customers and reports you open will be listed here.</Empty> : (
          <ul className="list-group list-group-flush">
            {data?.items.map((r) => (
              <li key={r._id} className="list-group-item list-group-item-action d-flex justify-content-between align-items-center" role="button" tabIndex={0} onClick={() => open(r)} onKeyDown={(e) => e.key === 'Enter' && open(r)}>
                <span><span className="pill role me-2">{r.entityType}</span><strong>{r.label}</strong> <span className="text-muted small">· {r.action}</span></span>
                <small className="text-muted">{dateTime(r.accessedAt)}</small>
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
}
