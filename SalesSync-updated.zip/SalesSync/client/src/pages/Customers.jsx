import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import api, { errorMessage } from '../services/api';
import useFetch from '../hooks/useFetch';
import { bumpData } from '../redux/uiSlice';
import { Empty, ErrorBox, Modal, Pager, Spinner } from '../components/ui.jsx';
import { dateOnly, dateTime, money, roleCan } from '../utils/format';

function CustomerForm({ customer, onClose, onSaved }) {
  const [form, setForm] = useState({ name: '', phone: '', email: '', address: '', notes: '', ...(customer || {}) });
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault();
    setSaving(true); setError(null);
    const body = { name: form.name, phone: form.phone, email: form.email, address: form.address, notes: form.notes };
    try {
      if (customer) await api.put(`/customers/${customer._id}`, body); else await api.post('/customers', body);
      onSaved();
    } catch (err) { setError(errorMessage(err)); } finally { setSaving(false); }
  };
  return (
    <Modal title={customer ? 'Edit customer' : 'Add customer'} onClose={onClose}>
      <form onSubmit={submit}>
        <ErrorBox message={error} />
        <div className="row g-3">
          <div className="col-12"><label className="form-label">Name *</label><input className="form-control" value={form.name} onChange={set('name')} required maxLength={100} /></div>
          <div className="col-md-6"><label className="form-label">Phone</label><input className="form-control" value={form.phone || ''} onChange={set('phone')} /></div>
          <div className="col-md-6"><label className="form-label">Email</label><input type="email" className="form-control" value={form.email || ''} onChange={set('email')} /></div>
          <div className="col-12"><label className="form-label">Address</label><input className="form-control" value={form.address || ''} onChange={set('address')} /></div>
          <div className="col-12"><label className="form-label">Notes</label><textarea rows={2} className="form-control" value={form.notes || ''} onChange={set('notes')} /></div>
        </div>
        <div className="d-flex justify-content-end gap-2 mt-4"><button type="button" className="btn btn-light" onClick={onClose}>Cancel</button><button className="btn btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save customer'}</button></div>
      </form>
    </Modal>
  );
}

function CustomerDetail({ id, onClose }) {
  const { data, loading, error } = useFetch(`/customers/${id}`);
  const c = data?.customer;
  return (
    <Modal title={c?.name || 'Customer'} onClose={onClose}>
      {loading && <Spinner />}<ErrorBox message={error} />
      {c && (<>
        <p className="mb-1">{c.phone || 'No phone'} · {c.email || 'No email'}</p>
        {c.address && <p className="mb-1">{c.address}</p>}
        <p className="text-muted">Total purchases {money(c.totalPurchases)} · Last purchase {dateOnly(c.lastPurchaseAt)}</p>
        <h6>Recent sales</h6>
        {data.sales.length === 0 ? <p className="text-muted mb-0">No sales recorded for this customer.</p> : (
          <ul className="list-unstyled mb-0">{data.sales.map((s) => <li key={s._id} className="d-flex justify-content-between border-bottom py-1"><span>{s.invoiceNumber} · {dateTime(s.createdAt)}</span><strong>{money(s.total)}</strong></li>)}</ul>
        )}
      </>)}
    </Modal>
  );
}

export default function Customers() {
  const dispatch = useDispatch();
  const [params, setParams] = useSearchParams();
  const user = useSelector((s) => s.auth.user);
  const [q, setQ] = useState('');
  const [debounced, setDebounced] = useState('');
  const [page, setPage] = useState(1);
  const [editing, setEditing] = useState(null);
  const [viewId, setViewId] = useState(params.get('view'));
  useEffect(() => { const t = setTimeout(() => { setDebounced(q); setPage(1); }, 350); return () => clearTimeout(t); }, [q]);
  const { data, loading, error, refetch } = useFetch('/customers', { params: { q: debounced, page, limit: 15 } });
  const closeView = () => { setViewId(null); if (params.get('view')) setParams({}); };
  const saved = () => { setEditing(null); refetch(); dispatch(bumpData()); };
  const remove = async (c) => {
    if (!window.confirm(`Delete ${c.name}?`)) return;
    try { await api.delete(`/customers/${c._id}`); saved(); } catch (e) { window.alert(errorMessage(e)); }
  };

  return (
    <>
      <div className="page-head"><h1>Customers</h1><button className="btn btn-primary" onClick={() => setEditing({})}>Add customer</button></div>
      <div className="panel panel-body mb-3"><input className="form-control" placeholder="Search name, phone or email" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search customers" /></div>
      <ErrorBox message={error} onRetry={refetch} />
      <div className="panel">
        {loading && !data ? <Spinner /> : data?.items.length === 0 ? <Empty title={debounced ? 'No customers match' : 'No customers yet'}>Add customers to attach them to sales.</Empty> : (
          <div className="table-responsive">
            <table className="table mb-0">
              <thead><tr><th>Name</th><th>Phone</th><th>Email</th><th className="text-end">Total purchases</th><th>Last purchase</th><th /></tr></thead>
              <tbody>{data?.items.map((c) => (
                <tr key={c._id}><td><button className="btn btn-link p-0 fw-semibold" onClick={() => setViewId(c._id)}>{c.name}</button></td><td>{c.phone || '—'}</td><td>{c.email || '—'}</td><td className="text-end">{money(c.totalPurchases)}</td><td>{dateOnly(c.lastPurchaseAt)}</td>
                  <td className="text-end text-nowrap"><button className="btn btn-sm btn-outline-primary me-1" onClick={() => setEditing(c)}>Edit</button>{roleCan(user, 'ADMIN', 'OWNER') && <button className="btn btn-sm btn-outline-danger" onClick={() => remove(c)}>Delete</button>}</td></tr>
              ))}</tbody>
            </table>
          </div>
        )}
        <Pager page={data?.page || 1} pages={data?.pages} onChange={setPage} />
      </div>
      {editing && <CustomerForm customer={editing._id ? editing : null} onClose={() => setEditing(null)} onSaved={saved} />}
      {viewId && <CustomerDetail id={viewId} onClose={closeView} />}
    </>
  );
}
