import { Link } from 'react-router-dom';
export default function NotFound() {
  return (
    <div className="empty-state" style={{ minHeight: '100vh', display: 'grid', placeContent: 'center' }}>
      <h3>Page not found</h3>
      <Link to="/">Back to the dashboard</Link>
    </div>
  );
}
