import { useState } from 'react';
import { useSelector } from 'react-redux';
import api, { errorMessage } from '../services/api';
import useFetch from '../hooks/useFetch';
import { ErrorBox, Modal, Pager, Spinner } from '../components/ui.jsx';
import { dateTime, money, num } from '../utils/format';

function NewUser({ onClose, onSaved }) {
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'STAFF' });
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setSaving(true); setError(null);
    try { await api.post('/admin/users', form); onSaved(); } catch (err) { setError(errorMessage(err)); } finally { setSaving(false); }
  };
  return (
    <Modal title="Create user" onClose={onClose}>
      <form onSubmit={submit}>
        <ErrorBox message={error} />
        <label className="form-label">Name</label><input className="form-control mb-3" value={form.name} onChange={set('name')} required minLength={2} />
        <label className="form-label">Email</label><input type="email" className="form-control mb-3" value={form.email} onChange={set('email')} required />
        <label className="form-label">Temporary password</label><input type="password" className="form-control mb-3" value={form.password} onChange={set('password')} required minLength={8} autoComplete="new-password" />
        <label className="form-label">Role</label>
        <select className="form-select mb-4" value={form.role} onChange={set('role')}><option>STAFF</option><option>OWNER</option><option>ADMIN</option></select>
        <div className="d-flex justify-content-end gap-2"><button type="button" className="btn btn-light" onClick={onClose}>Cancel</button><button className="btn btn-primary" disabled={saving}>{saving ? 'Creating…' : 'Create user'}</button></div>
      </form>
    </Modal>
  );
}

export default function Admin() {
  const me = useSelector((s) => s.auth.user);
  const [page, setPage] = useState(1);
  const [q, setQ] = useState('');
  const [creating, setCreating] = useState(false);
  const [rowError, setRowError] = useState(null);
  const stats = useFetch('/admin/stats');
  const users = useFetch('/admin/users', { params: { page, limit: 20, q } });

  const patch = async (u, body) => {
    setRowError(null);
    try { await api.patch(`/admin/users/${u.id}`, body); users.refetch(); stats.refetch(); } catch (e) { setRowError(errorMessage(e)); }
  };
  const s = stats.data?.stats;

  return (
    <>
      <div className="page-head"><h1>Admin panel</h1><button className="btn btn-primary" onClick={() => setCreating(true)}>Create user</button></div>
      <ErrorBox message={stats.error} onRetry={stats.refetch} />
      {s && (
        <div className="row g-3 mb-3">
          {[['Users', num(s.users)], ['Admins / Owners / Staff', `${s.byRole.ADMIN || 0} / ${s.byRole.OWNER || 0} / ${s.byRole.STAFF || 0}`], ['Products', num(s.products)], ['Customers', num(s.customers)], ['Lifetime revenue', money(s.revenue)]].map(([l, v]) => (
            <div className="col-6 col-lg" key={l}><div className="panel stat"><div className="label">{l}</div><div className="value fs-4">{v}</div></div></div>
          ))}
        </div>
      )}
      <div className="panel">
        <div className="panel-head"><strong>Users</strong><input className="form-control form-control-sm" style={{ maxWidth: 240 }} placeholder="Search name or email" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} /></div>
        <ErrorBox message={rowError || users.error} />
        {users.loading && !users.data ? <Spinner /> : (
          <div className="table-responsive">
            <table className="table mb-0">
              <thead><tr><th>Name</th><th>Email</th><th>Sign-in</th><th>Role</th><th>Last login</th><th>Status</th></tr></thead>
              <tbody>{users.data?.items.map((u) => (
                <tr key={u.id}><td>{u.name}{u.id === me.id && <span className="text-muted"> (you)</span>}</td><td>{u.email}</td><td>{u.authProvider}</td>
                  <td><select className="form-select form-select-sm" style={{ width: 110 }} value={u.role} disabled={u.id === me.id} onChange={(e) => patch(u, { role: e.target.value })} aria-label={`Role for ${u.name}`}><option>ADMIN</option><option>OWNER</option><option>STAFF</option></select></td>
                  <td>{dateTime(u.lastLoginAt)}</td>
                  <td><button className={`btn btn-sm ${u.isActive ? 'btn-outline-danger' : 'btn-outline-success'}`} disabled={u.id === me.id} onClick={() => patch(u, { isActive: !u.isActive })}>{u.isActive ? 'Disable' : 'Enable'}</button></td></tr>
              ))}</tbody>
            </table>
          </div>
        )}
        <Pager page={users.data?.page || 1} pages={users.data?.pages} onChange={setPage} />
      </div>
      {creating && <NewUser onClose={() => setCreating(false)} onSaved={() => { setCreating(false); users.refetch(); stats.refetch(); }} />}
    </>
  );
}
