import { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation, Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../redux/authSlice';
import { fetchNotifications } from '../redux/notificationsSlice';
import Icon from './Icon.jsx';
import VoiceAssistant from './VoiceAssistant.jsx';

const NAV = [
  { to: '/', label: 'Dashboard', icon: 'home', end: true },
  { to: '/products', label: 'Products', icon: 'box' },
  { to: '/inventory', label: 'Inventory', icon: 'layers' },
  { to: '/sales/new', label: 'New sale', icon: 'plus' },
  { to: '/sales', label: 'Sales history', icon: 'receipt', end: true },
  { to: '/customers', label: 'Customers', icon: 'users' },
  { to: '/reports', label: 'Reports', icon: 'chart' },
  { to: '/recent', label: 'Recently opened', icon: 'clock' },
  { to: '/notifications', label: 'Alerts', icon: 'bell' },
];

export default function Layout() {
  const dispatch = useDispatch();
  const location = useLocation();
  const user = useSelector((s) => s.auth.user);
  const unread = useSelector((s) => s.notifications.unread);
  const [open, setOpen] = useState(false);

  useEffect(() => setOpen(false), [location.pathname]);
  useEffect(() => {
    dispatch(fetchNotifications());
    const t = setInterval(() => dispatch(fetchNotifications()), 60000);
    return () => clearInterval(t);
  }, [dispatch]);

  return (
    <div className="shell">
      <div className={`scrim ${open ? 'open' : ''}`} onClick={() => setOpen(false)} />
      <aside className={`sidebar ${open ? 'open' : ''}`} aria-label="Main navigation">
        <div className="brand">Sales<span>Sync</span></div>
        <nav className="d-flex flex-column gap-1">
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} className={({ isActive }) => `nav-link-item ${isActive ? 'active' : ''}`}>
              <Icon name={n.icon} /> {n.label}
            </NavLink>
          ))}
          {user.role === 'ADMIN' && (
            <>
              <div className="nav-sep">Administration</div>
              <NavLink to="/admin" className={({ isActive }) => `nav-link-item ${isActive ? 'active' : ''}`}><Icon name="shield" /> Admin panel</NavLink>
            </>
          )}
        </nav>
      </aside>

      <div className="main">
        <header className="topbar">
          <button className="btn btn-light d-lg-none" onClick={() => setOpen(true)} aria-label="Open menu"><Icon name="menu" /></button>
          <div className="ms-auto d-flex align-items-center gap-3">
            <Link to="/notifications" className="bell text-dark" aria-label={`${unread} unread alerts`}>
              <Icon name="bell" size={22} />
              {unread > 0 && <span className="badge rounded-pill text-bg-danger">{unread > 99 ? '99+' : unread}</span>}
            </Link>
            <div className="text-end lh-sm d-none d-sm-block">
              <div className="fw-semibold">{user.name}</div>
              <span className="pill role">{user.role}</span>
            </div>
            <button className="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1" onClick={() => dispatch(logout())}>
              <Icon name="logout" size={16} /> Log out
            </button>
          </div>
        </header>
        <main className="content">
          <Outlet />
        </main>
      </div>
      <VoiceAssistant />
    </div>
  );
}
