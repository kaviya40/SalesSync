import { useCallback, useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import useVoiceCommand from '../hooks/useVoiceCommand';
import { addUserMessage, clearConversation, sendVoiceCommand, setLang } from '../redux/voiceSlice';
import { toggleVoice } from '../redux/uiSlice';
import Icon from './Icon.jsx';

const EXAMPLES = ['Sell 2 smartphones', 'Add 10 shirts to stock', 'How many chargers are available?', "Show today's sales", 'Blue shirt 5 sell pannu', '10 shirt stock la add pannu'];

export default function VoiceAssistant() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const open = useSelector((s) => s.ui.voiceOpen);
  const { history, lang, busy, lastNavigate, context } = useSelector((s) => s.voice);
  const [text, setText] = useState('');
  const [speakOn, setSpeakOn] = useState(true);
  const logRef = useRef(null);
  const spoken = useRef(0);

  const submit = useCallback((transcript) => {
    const clean = transcript.trim();
    if (!clean) return;
    dispatch(addUserMessage(clean));
    dispatch(sendVoiceCommand(clean));
  }, [dispatch]);

  const { supported, listening, interim, error, start, stop } = useVoiceCommand({ lang, onFinal: submit });

  // Auto-scroll, read replies aloud, and follow navigation hints from the server
  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
    const last = history[history.length - 1];
    if (last && last.role === 'assistant' && last.id !== spoken.current) {
      spoken.current = last.id;
      if (speakOn && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(last.text);
        u.lang = lang === 'ta-IN' ? 'ta-IN' : 'en-IN';
        window.speechSynthesis.speak(u);
      }
    }
  }, [history, speakOn, lang]);

  useEffect(() => { if (lastNavigate) navigate(lastNavigate); }, [lastNavigate, navigate]);

  const onMic = () => {
    if (!open) dispatch(toggleVoice(true));
    if (listening) stop();
    else { window.speechSynthesis?.cancel(); start(); }
  };

  return (
    <>
      {open && (
        <section className="voice-panel" aria-label="Voice assistant">
          <div className="vhead">
            <strong>Voice assistant</strong>
            <div className="d-flex align-items-center gap-2">
              <select className="form-select form-select-sm" style={{ width: 'auto' }} value={lang} onChange={(e) => dispatch(setLang(e.target.value))} aria-label="Speech language">
                <option value="en-IN">English / Tanglish</option>
                <option value="ta-IN">தமிழ் (Tamil)</option>
                <option value="en-US">English (US)</option>
              </select>
              <button className="btn btn-sm btn-light" onClick={() => dispatch(toggleVoice(false))} aria-label="Close assistant"><Icon name="x" size={16} /></button>
            </div>
          </div>
          <div className="voice-log" ref={logRef} aria-live="polite">
            {history.length === 0 && <div className="text-muted small">Tap the mic and speak, or type a command below. I can add stock, remove stock, sell items, check availability and show sales.</div>}
            {history.map((m) => (
              <div key={m.id} className={`bubble ${m.role} ${m.role === 'assistant' ? (m.type === 'CLARIFY' ? 'ask' : m.ok === false ? 'bad' : '') : ''}`}>{m.text}</div>
            ))}
            {listening && <div className="bubble user" style={{ opacity: 0.7 }}>{interim || 'Listening…'}</div>}
            {busy && <div className="text-muted small">Working…</div>}
          </div>
          <div className="voice-foot">
            {error && <div className="text-danger small mb-2">{error}</div>}
            {!supported && <div className="text-muted small mb-2">This browser has no speech recognition. Type commands instead (Chrome/Edge support voice).</div>}
            {context.pending && <div className="small text-muted mb-2">Waiting for your answer to the question above…</div>}
            <div className="chips">
              {EXAMPLES.slice(0, 4).map((e) => <button key={e} className="chip" onClick={() => submit(e)}>{e}</button>)}
            </div>
            <form className="d-flex gap-2" onSubmit={(e) => { e.preventDefault(); submit(text); setText(''); }}>
              <input className="form-control" placeholder="Type a command…" value={text} onChange={(e) => setText(e.target.value)} maxLength={300} />
              <button className="btn btn-primary" disabled={busy || !text.trim()}>Send</button>
            </form>
            <div className="d-flex justify-content-between mt-2 small">
              <label className="text-muted"><input type="checkbox" className="form-check-input me-1" checked={speakOn} onChange={(e) => setSpeakOn(e.target.checked)} />Read replies aloud</label>
              <button className="btn btn-link btn-sm p-0" onClick={() => dispatch(clearConversation())}>Clear</button>
            </div>
          </div>
        </section>
      )}
      <button className={`voice-fab ${listening ? 'listening' : ''}`} onClick={onMic} aria-label={listening ? 'Stop listening' : 'Start voice command'} title="Voice command">
        <Icon name="mic" size={26} />
      </button>
    </>
  );
}
