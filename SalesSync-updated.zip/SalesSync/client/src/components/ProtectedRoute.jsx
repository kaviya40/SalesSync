import { Navigate, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';

export default function ProtectedRoute({ children, roles }) {
  const user = useSelector((s) => s.auth.user);
  const location = useLocation();
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;
  if (roles && !roles.includes(user.role)) {
    return (
      <div className="empty-state">
        <h3>You don't have access to this page</h3>
        <p>This area is limited to: {roles.join(', ')}.</p>
      </div>
    );
  }
  return children;
}
