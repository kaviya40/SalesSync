import { useEffect, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';
import { googleLogin } from '../redux/authSlice';

const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const SRC = 'https://accounts.google.com/gsi/client';

/** Google Sign-In (Google Identity Services). The ID token is verified by the server. */
export default function GoogleButton() {
  const ref = useRef(null);
  const dispatch = useDispatch();
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!CLIENT_ID) return undefined;
    const init = () => {
      if (!window.google?.accounts?.id || !ref.current) return;
      window.google.accounts.id.initialize({ client_id: CLIENT_ID, callback: (r) => dispatch(googleLogin({ credential: r.credential })) });
      window.google.accounts.id.renderButton(ref.current, { theme: 'outline', size: 'large', width: 340, text: 'continue_with' });
    };
    if (window.google?.accounts?.id) { init(); return undefined; }
    let script = document.querySelector(`script[src="${SRC}"]`);
    if (!script) {
      script = document.createElement('script');
      script.src = SRC;
      script.async = true;
      document.head.appendChild(script);
    }
    script.addEventListener('load', init);
    script.addEventListener('error', () => setFailed(true));
    return () => script.removeEventListener('load', init);
  }, [dispatch]);

  if (!CLIENT_ID) return <p className="text-muted small text-center mb-0">Google sign-in is not configured (set VITE_GOOGLE_CLIENT_ID).</p>;
  if (failed) return <p className="text-muted small text-center mb-0">Google sign-in could not be loaded.</p>;
  return <div ref={ref} className="d-flex justify-content-center" />;
}
