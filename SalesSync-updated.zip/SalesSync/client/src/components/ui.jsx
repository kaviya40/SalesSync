import { useEffect } from 'react';

export function Spinner({ label = 'Loading…' }) {
  return (
    <div className="empty-state" role="status">
      <div className="spinner-border spinner-border-sm text-secondary me-2" /> {label}
    </div>
  );
}

export function ErrorBox({ message, onRetry }) {
  if (!message) return null;
  return (
    <div className="alert alert-danger d-flex justify-content-between align-items-center" role="alert">
      <span>{message}</span>
      {onRetry && <button className="btn btn-sm btn-outline-danger" onClick={onRetry}>Try again</button>}
    </div>
  );
}

export function Empty({ title, children }) {
  return (
    <div className="empty-state">
      <h3>{title}</h3>
      <div>{children}</div>
    </div>
  );
}

export function Pager({ page, pages, onChange }) {
  if (!pages || pages <= 1) return null;
  return (
    <div className="d-flex justify-content-center align-items-center gap-2 py-3">
      <button className="btn btn-sm btn-outline-secondary" disabled={page <= 1} onClick={() => onChange(page - 1)}>Previous</button>
      <span className="text-muted small">Page {page} of {pages}</span>
      <button className="btn btn-sm btn-outline-secondary" disabled={page >= pages} onClick={() => onChange(page + 1)}>Next</button>
    </div>
  );
}

export function Modal({ title, onClose, children, footer, wide }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="modal-backdrop-x" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal-card" role="dialog" aria-modal="true" aria-label={title} style={wide ? { maxWidth: 820 } : undefined}>
        <div className="head">
          <h5 className="m-0">{title}</h5>
          <button className="btn-close" aria-label="Close" onClick={onClose} />
        </div>
        <div className="body">{children}</div>
        {footer && <div className="foot">{footer}</div>}
      </div>
    </div>
  );
}

export function StockPill({ product }) {
  const state = product.stock <= 0 ? 'out' : product.stock <= product.lowStockThreshold ? 'low' : 'ok';
  const text = state === 'out' ? 'Out of stock' : state === 'low' ? `Low · ${product.stock}` : `${product.stock} in stock`;
  return <span className={`pill ${state}`}>{text}</span>;
}

export function Thumb({ src, name }) {
  return src ? <img className="thumb" src={src} alt="" loading="lazy" /> : <div className="thumb empty" aria-hidden="true">{(name || '?')[0].toUpperCase()}</div>;
}
