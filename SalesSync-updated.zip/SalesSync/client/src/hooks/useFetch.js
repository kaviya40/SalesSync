import { useCallback, useEffect, useRef, useState } from 'react';
import api, { errorMessage } from '../services/api';

/**
 * useFetch(url, { params, enabled, deps })
 * GETs `url` and returns { data, loading, error, refetch }. Re-fetches when url, params or deps change.
 */
export default function useFetch(url, { params, enabled = true, deps = [] } = {}) {
  const [state, setState] = useState({ data: null, loading: Boolean(enabled), error: null });
  const [tick, setTick] = useState(0);
  const paramsKey = JSON.stringify(params || {});
  const seq = useRef(0);

  useEffect(() => {
    if (!enabled || !url) return undefined;
    const controller = new AbortController();
    const id = ++seq.current;
    setState((s) => ({ ...s, loading: true, error: null }));
    api
      .get(url, { params: JSON.parse(paramsKey), signal: controller.signal })
      .then((res) => id === seq.current && setState({ data: res.data, loading: false, error: null }))
      .catch((err) => {
        if (err.code === 'ERR_CANCELED') return;
        if (id === seq.current) setState((s) => ({ ...s, loading: false, error: errorMessage(err) }));
      });
    return () => controller.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, paramsKey, enabled, tick, ...deps]);

  const refetch = useCallback(() => setTick((t) => t + 1), []);
  return { ...state, refetch };
}
