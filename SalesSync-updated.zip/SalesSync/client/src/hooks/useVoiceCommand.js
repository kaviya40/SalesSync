import { useCallback, useEffect, useRef, useState } from 'react';

const SpeechRecognition = typeof window !== 'undefined' ? window.SpeechRecognition || window.webkitSpeechRecognition : null;

const ERRORS = {
  'not-allowed': 'Microphone permission was denied. Allow microphone access in the browser address bar.',
  'service-not-allowed': 'Speech recognition is blocked in this browser.',
  'no-speech': "I didn't hear anything. Tap the mic and try again.",
  'audio-capture': 'No microphone was found.',
  network: 'Speech recognition needs an internet connection in this browser.',
};

/**
 * useVoiceCommand({ lang, onFinal })
 * Wraps the browser Speech Recognition API. Calls onFinal(transcript) once per spoken command.
 */
export default function useVoiceCommand({ lang = 'en-IN', onFinal } = {}) {
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState('');
  const [error, setError] = useState(null);
  const recRef = useRef(null);
  const finalRef = useRef(onFinal);
  finalRef.current = onFinal;

  const stop = useCallback(() => {
    if (recRef.current) recRef.current.stop();
  }, []);

  const start = useCallback(() => {
    if (!SpeechRecognition) {
      setError('Speech recognition is not supported in this browser. Use Chrome or Edge, or type your command.');
      return;
    }
    if (recRef.current) recRef.current.abort();
    const rec = new SpeechRecognition();
    rec.lang = lang;
    rec.interimResults = true;
    rec.continuous = false;
    rec.maxAlternatives = 1;
    let finalText = '';

    rec.onstart = () => { setError(null); setInterim(''); setListening(true); };
    rec.onresult = (e) => {
      let live = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const text = e.results[i][0].transcript;
        if (e.results[i].isFinal) finalText += text;
        else live += text;
      }
      setInterim(finalText + live);
    };
    rec.onerror = (e) => { if (e.error !== 'aborted') setError(ERRORS[e.error] || `Speech error: ${e.error}`); };
    rec.onend = () => {
      setListening(false);
      setInterim('');
      recRef.current = null;
      const text = finalText.trim();
      if (text && finalRef.current) finalRef.current(text);
    };
    recRef.current = rec;
    try { rec.start(); } catch (e) { setError('Could not start the microphone.'); }
  }, [lang]);

  useEffect(() => () => recRef.current && recRef.current.abort(), []);

  return { supported: Boolean(SpeechRecognition), listening, interim, error, start, stop, clearError: () => setError(null) };
}
