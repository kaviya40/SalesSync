export const money = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(Number(n) || 0);
export const num = (n) => new Intl.NumberFormat('en-IN').format(Number(n) || 0);
export const dateTime = (d) => (d ? new Date(d).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : '—');
export const dateOnly = (d) => (d ? new Date(d).toLocaleDateString('en-IN', { dateStyle: 'medium' }) : '—');
export const productLabel = (p) => [p?.name, p?.color, p?.size].filter(Boolean).join(' · ');
export const stockState = (p) => (p.stock <= 0 ? 'out' : p.stock <= p.lowStockThreshold ? 'low' : 'ok');
export const roleCan = (user, ...roles) => Boolean(user && roles.includes(user.role));

export function periodLabel(iso, period) {
  const d = new Date(iso);
  if (period === 'monthly') return d.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' });
  if (period === 'weekly') return 'Wk ' + d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
}
