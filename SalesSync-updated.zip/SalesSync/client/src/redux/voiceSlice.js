import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import api, { errorMessage } from '../services/api';
import { bumpData } from './uiSlice';
import { fetchNotifications } from './notificationsSlice';

export const sendVoiceCommand = createAsyncThunk('voice/send', async (transcript, { getState, dispatch, rejectWithValue }) => {
  try {
    const { context } = getState().voice;
    const { data } = await api.post('/voice/command', { transcript, context });
    if (data.refresh?.length) {
      dispatch(bumpData());
      dispatch(fetchNotifications());
    }
    return data;
  } catch (err) {
    return rejectWithValue(errorMessage(err));
  }
});

let id = 0;
const slice = createSlice({
  name: 'voice',
  initialState: { history: [], context: { lastProduct: null, pending: null }, lang: 'en-IN', busy: false, lastNavigate: null },
  reducers: {
    setLang(state, a) { state.lang = a.payload; },
    addUserMessage(state, a) { state.history.push({ id: ++id, role: 'user', text: a.payload }); },
    clearConversation(state) { state.history = []; state.context = { lastProduct: null, pending: null }; },
  },
  extraReducers: (b) => {
    b.addCase(sendVoiceCommand.pending, (s) => { s.busy = true; s.lastNavigate = null; })
      .addCase(sendVoiceCommand.fulfilled, (s, a) => {
        s.busy = false;
        s.context = a.payload.context || { lastProduct: null, pending: null };
        s.lastNavigate = a.payload.navigate || null;
        s.history.push({ id: ++id, role: 'assistant', text: a.payload.message, ok: a.payload.success, type: a.payload.type });
      })
      .addCase(sendVoiceCommand.rejected, (s, a) => {
        s.busy = false;
        s.history.push({ id: ++id, role: 'assistant', text: a.payload || 'Command failed', ok: false, type: 'ERROR' });
      });
  },
});

export const { setLang, addUserMessage, clearConversation } = slice.actions;
export default slice.reducer;
