import { configureStore } from '@reduxjs/toolkit';
import auth from './authSlice';
import products from './productsSlice';
import notifications from './notificationsSlice';
import voice from './voiceSlice';
import ui from './uiSlice';

export const store = configureStore({ reducer: { auth, products, notifications, voice, ui } });
