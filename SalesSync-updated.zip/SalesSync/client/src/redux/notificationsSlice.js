import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import api from '../services/api';

export const fetchNotifications = createAsyncThunk('notifications/fetch', async () => {
  const { data } = await api.get('/notifications');
  return data;
});
export const markAllRead = createAsyncThunk('notifications/readAll', async () => {
  await api.patch('/notifications/read-all');
});
export const markRead = createAsyncThunk('notifications/read', async (id) => {
  await api.patch(`/notifications/${id}/read`);
  return id;
});

const slice = createSlice({
  name: 'notifications',
  initialState: { items: [], unread: 0 },
  reducers: {},
  extraReducers: (b) => {
    b.addCase(fetchNotifications.fulfilled, (s, a) => { s.items = a.payload.items; s.unread = a.payload.unread; })
      .addCase(markAllRead.fulfilled, (s) => { s.items.forEach((n) => { n.read = true; }); s.unread = 0; })
      .addCase(markRead.fulfilled, (s, a) => {
        const n = s.items.find((x) => x._id === a.payload);
        if (n && !n.read) { n.read = true; s.unread = Math.max(0, s.unread - 1); }
      });
  },
});

export default slice.reducer;
