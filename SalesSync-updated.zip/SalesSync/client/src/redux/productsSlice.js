import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import api, { errorMessage } from '../services/api';

export const fetchProducts = createAsyncThunk('products/fetch', async (params, { rejectWithValue }) => {
  try {
    const clean = Object.fromEntries(Object.entries(params).filter(([, v]) => v !== '' && v != null));
    const { data } = await api.get('/products', { params: clean });
    return data;
  } catch (err) {
    return rejectWithValue(errorMessage(err));
  }
});

const defaultFilters = { q: '', category: '', stockStatus: '', sort: 'name', order: 'asc', page: 1, limit: 12 };

const slice = createSlice({
  name: 'products',
  initialState: { items: [], total: 0, pages: 1, loading: false, error: null, filters: defaultFilters },
  reducers: {
    setFilters(state, action) {
      const changedPage = 'page' in action.payload;
      state.filters = { ...state.filters, ...action.payload, ...(changedPage ? {} : { page: 1 }) };
    },
    resetFilters(state) {
      state.filters = defaultFilters;
    },
  },
  extraReducers: (b) => {
    b.addCase(fetchProducts.pending, (s) => { s.loading = true; s.error = null; })
      .addCase(fetchProducts.fulfilled, (s, a) => { s.loading = false; s.items = a.payload.items; s.total = a.payload.total; s.pages = a.payload.pages; })
      .addCase(fetchProducts.rejected, (s, a) => { s.loading = false; s.error = a.payload; });
  },
});

export const { setFilters, resetFilters } = slice.actions;
export default slice.reducer;
