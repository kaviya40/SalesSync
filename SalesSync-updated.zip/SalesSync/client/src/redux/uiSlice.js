import { createSlice } from '@reduxjs/toolkit';

// dataVersion is bumped after any change made by the voice assistant so pages re-fetch fresh data.
const slice = createSlice({
  name: 'ui',
  initialState: { dataVersion: 0, voiceOpen: false },
  reducers: {
    bumpData(state) { state.dataVersion += 1; },
    toggleVoice(state, a) { state.voiceOpen = a.payload ?? !state.voiceOpen; },
  },
});

export const { bumpData, toggleVoice } = slice.actions;
export default slice.reducer;
