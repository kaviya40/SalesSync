import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import api, { TOKEN_KEY, errorMessage } from '../services/api';

const persist = (data) => localStorage.setItem(TOKEN_KEY, data.token);

const call = (name, path) =>
  createAsyncThunk(`auth/${name}`, async (body, { rejectWithValue }) => {
    try {
      const { data } = await api.post(path, body);
      persist(data);
      return data;
    } catch (err) {
      return rejectWithValue(errorMessage(err));
    }
  });

export const login = call('login', '/auth/login');
export const register = call('register', '/auth/register');
export const googleLogin = call('google', '/auth/google');

export const loadMe = createAsyncThunk('auth/me', async (_, { rejectWithValue }) => {
  try {
    const { data } = await api.get('/auth/me');
    return data.user;
  } catch (err) {
    return rejectWithValue(errorMessage(err));
  }
});

const hasToken = Boolean(localStorage.getItem(TOKEN_KEY));

const slice = createSlice({
  name: 'auth',
  initialState: { user: null, loading: false, initializing: hasToken, error: null },
  reducers: {
    logout(state) {
      localStorage.removeItem(TOKEN_KEY);
      state.user = null;
      state.error = null;
      state.initializing = false;
    },
    clearAuthError(state) {
      state.error = null;
    },
  },
  extraReducers: (b) => {
    for (const thunk of [login, register, googleLogin]) {
      b.addCase(thunk.pending, (s) => { s.loading = true; s.error = null; })
        .addCase(thunk.fulfilled, (s, a) => { s.loading = false; s.user = a.payload.user; })
        .addCase(thunk.rejected, (s, a) => { s.loading = false; s.error = a.payload || 'Request failed'; });
    }
    b.addCase(loadMe.fulfilled, (s, a) => { s.user = a.payload; s.initializing = false; })
      .addCase(loadMe.rejected, (s) => { localStorage.removeItem(TOKEN_KEY); s.user = null; s.initializing = false; });
  },
});

export const { logout, clearAuthError } = slice.actions;
export default slice.reducer;
